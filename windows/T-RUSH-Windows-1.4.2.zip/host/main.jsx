/* TitleFlow host. ES3 only: shared by AE 2024–2026 on Windows and macOS. */
var TitleFlow = (function () {
    var PREFIX = 'TITLEFLOW/1:', FIELDS = ['name_ru', 'name_en', 'work_ru', 'work_en'];
    var session = null;
    // Self-contained JSON codec; never eval spreadsheet data. ExtendScript may lack JSON.
    function encode(v) {
        if (v === null || v === undefined) return 'null';
        if (typeof v === 'string') return '"' + v.replace(/["\\\x00-\x1f\u2028\u2029]/g, function (c) {
            var n = c.charCodeAt(0).toString(16); return '\\u' + ('0000' + n).slice(-4);
        }) + '"';
        if (typeof v === 'number') return isFinite(v) ? String(v) : 'null';
        if (typeof v === 'boolean') return v ? 'true' : 'false';
        var parts = [], k;
        if (v instanceof Array) { for (k = 0; k < v.length; k++) parts.push(encode(v[k])); return '[' + parts.join(',') + ']'; }
        for (k in v) if (Object.prototype.hasOwnProperty.call(v, k)) parts.push(encode(k) + ':' + encode(v[k]));
        return '{' + parts.join(',') + '}';
    }
    function decode(text) {
        var pos = 0, depth = 0;
        function ws() { while (/\s/.test(text.charAt(pos)) && pos < text.length) pos++; }
        function fail() { throw new Error('Некорректный JSON: ' + pos); }
        function value() {
            ws(); if (++depth > 50) fail();
            var c = text.charAt(pos++), out, k, m;
            if (c === '"') {
                out = ''; var done = false;
                while (pos < text.length) {
                    c = text.charAt(pos++);
                    if (c === '"') { done = true; break; }
                    if (c === '\\') {
                        c = text.charAt(pos++);
                        if (c === 'u') { m = text.substr(pos, 4); if (!/^[\da-f]{4}$/i.test(m)) fail(); out += String.fromCharCode(parseInt(m, 16)); pos += 4; }
                        else if (c === '"' || c === '\\' || c === '/') out += c;
                        else if (c === 'n') out += '\n'; else if (c === 'r') out += '\r'; else if (c === 't') out += '\t';
                        else if (c === 'b') out += '\b'; else if (c === 'f') out += '\f'; else fail();
                    } else { if (c.charCodeAt(0) < 32) fail(); out += c; }
                }
                if (!done) fail();
            } else if (c === '[' || c === '{') {
                var array = c === '[', end = array ? ']' : '}'; out = array ? [] : {};
                ws();
                if (text.charAt(pos) === end) pos++;
                else while (true) {
                    if (array) out.push(value());
                    else { ws(); if (text.charAt(pos) !== '"') fail(); k = value(); if (k === '__proto__') fail(); ws(); if (text.charAt(pos++) !== ':') fail(); out[k] = value(); }
                    ws(); c = text.charAt(pos++); if (c === end) break; if (c !== ',') fail();
                }
            } else {
                pos--; m = /^(true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(text.substr(pos));
                if (!m) fail(); pos += m[0].length;
                out = m[0] === 'true' ? true : m[0] === 'false' ? false : m[0] === 'null' ? null : Number(m[0]);
            }
            depth--; return out;
        }
        var result = value(); ws(); if (pos !== text.length) fail(); return result;
    }
    function requireProject(path) {
        if (!app.project || !app.project.file) throw new Error('Сначала сохраните проект .aep.');
        if (path && app.project.file.fsName !== path) throw new Error('Открыт другой проект. Повторите проверку.');
        if (app.project.renderQueue.rendering) throw new Error('Дождитесь окончания рендера.');
    }
    function findComp(id) {
        for (var i = 1; i <= app.project.numItems; i++) {
            var item = app.project.item(i); if (item.id === Number(id) && item instanceof CompItem) return item;
        }
        throw new Error('Композиция не найдена. Обновите список.');
    }
    function meta(item) {
        if (!item.comment || item.comment.indexOf(PREFIX) !== 0) return null;
        try { return decode(item.comment.substr(PREFIX.length)); } catch (_) { throw new Error('Повреждена история TitleFlow у ' + item.name); }
    }
    function latest(scope) {
        var map = {}, result = [], i, m, item, k;
        for (i = 1; i <= app.project.numItems; i++) {
            item = app.project.item(i); if (!(item instanceof CompItem)) continue;
            m = meta(item); if (!m || m.scope !== scope || !m.record) continue;
            k = '$' + m.record.id;
            if (!map[k] || map[k].revision < m.revision) { m.compId = item.id; map[k] = m; }
        }
        for (k in map) if (Object.prototype.hasOwnProperty.call(map, k)) result.push(map[k]);
        result.sort(function (a, b) { return a.record.id < b.record.id ? -1 : a.record.id > b.record.id ? 1 : 0; });
        return result;
    }
    function signature(items) {
        var a = []; for (var i = 0; i < items.length; i++) a.push([items[i].compId, items[i].revision]); return encode(a);
    }
    function walkProperties(group, fn) {
        for (var i = 1; i <= group.numProperties; i++) {
            var p = group.property(i); fn(p); if (p.numProperties) walkProperties(p, fn);
        }
    }
    function supportedTextExpression(source) {
        // Only the reviewed self-value formatter: first name / surname on two lines.
        // Never infer safety from the mere presence of "value" in arbitrary code.
        var expression = String(source.expression || '').replace(/\s+/g, '');
        return expression === 'vartxt=value.toString().trim();txt=txt.replace(/[\\t]+/,"\\r");text.sourceText.style.setText(txt);' ||
            expression === "vartxt=value.toString().trim();txt=txt.replace(/[\\t]+/,'\\r');text.sourceText.style.setText(txt);";
    }
    function inspect(root, layerMap, discovery) {
        var visited = {}, counts = {}, errors = [], warnings = [], comps = [], textCounts = {}, mappings = [], fieldsByLayer = {};
        var f;
        if (layerMap && layerMap.length) mappings = layerMap;
        else for (f = 0; f < FIELDS.length; f++) mappings.push({ layer: FIELDS[f], field: FIELDS[f] });
        for (f = 0; f < mappings.length; f++) { counts[mappings[f].layer] = 0; fieldsByLayer[mappings[f].layer] = mappings[f].field; }
        function visit(comp) {
            if (visited['$' + comp.id]) return; visited['$' + comp.id] = true; comps.push(comp);
            for (var i = 1; i <= comp.numLayers; i++) {
                var layer = comp.layer(i), name = layer.name, text = layer.property('ADBE Text Properties');
                if (text) textCounts[name] = (textCounts[name] || 0) + 1;
                if (!discovery && Object.prototype.hasOwnProperty.call(counts, name)) {
                    if (!text) errors.push(comp.name + ' / ' + name + ': слой не текстовый.');
                    else {
                        if (!discovery) counts[name]++; var source = text.property('ADBE Text Document');
                        if (source.expressionEnabled && !supportedTextExpression(source)) errors.push(comp.name + ' / ' + name + ': Source Text управляется выражением.');
                        if (source.numKeys) errors.push(comp.name + ' / ' + name + ': у Source Text есть ключевые кадры.');
                    }
                }
                walkProperties(layer, function (p) {
                    if (p.expressionEnabled && /\bcomp\s*\(/.test(p.expression)) errors.push(comp.name + ' / ' + name + ': выражение с comp(...). Нужна адаптация ссылок перед пакетным копированием.');
                });
                try { if (layer.essentialProperty && layer.essentialProperty.numProperties) errors.push(comp.name + ' / ' + name + ': Essential Properties требуют проверки и адаптации шаблона.'); } catch (_) {}
                if (layer.source instanceof CompItem) visit(layer.source);
            }
        }
        visit(root);
        if (!discovery) for (f = 0; f < mappings.length; f++) {
            if (!counts[mappings[f].layer]) errors.push('Не найден текстовый слой ' + mappings[f].layer);
            if (counts[mappings[f].layer] > 1) warnings.push(mappings[f].layer + ': будет обновлено слоёв — ' + counts[mappings[f].layer]);
        }
        var textLayers = [], textName;
        for (textName in textCounts) if (Object.prototype.hasOwnProperty.call(textCounts, textName)) textLayers.push({ name: textName, count: textCounts[textName] });
        textLayers.sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
        return { counts: counts, textLayers: textLayers, errors: errors, warnings: warnings, compositions: comps.length };
    }
    function outputInfo(comp, outputTemplate, renderTemplate) {
        var rq = null;
        try {
            rq = app.project.renderQueue.items.add(comp); rq.render = false;
            if (renderTemplate) rq.applyTemplate(renderTemplate);
            if (outputTemplate) rq.outputModule(1).applyTemplate(outputTemplate);
            var om = rq.outputModule(1), file = om.file, ext = file ? /\.(mov|mp4|avi|mxf)$/i.exec(file.name) : null;
            var settings = om.getSettings(GetSettingsFormat.STRING);
            // Windows may leave the temporary job's file unset or without an extension.
            // Determine the container from actual module settings, not the preset name.
            {
                var format = String(settings.Format || settings['File Format'] || '').toLowerCase();
                var inferred = /quicktime|\bmov\b/.test(format) ? '.mov' : /\bmxf\b/.test(format) ? '.mxf' : /avi|video for windows/.test(format) ? '.avi' : /mp4|mpeg.?4|h\.?264|hevc|h\.?265/.test(format) ? '.mp4' : null;
                if (inferred) ext = [inferred];
            }
            // Ask AE to normalize a scratch filename: some modules retain a stale
            // extension until file is assigned. No file is rendered or written here.
            if (ext) {
                rq.outputModule(1).file = new File(Folder.temp.fsName + '/trush-container-probe' + ext[0]);
                var probe = rq.outputModule(1).file;
                var actualExtension = probe ? /\.(mov|mp4|avi|mxf)$/i.exec(probe.name) : null;
                if (actualExtension) ext = actualExtension;
                else throw new Error('Не удалось определить расширение Output Module после проверки имени файла.');
            }
            om = rq.outputModule(1);
            settings = om.getSettings(GetSettingsFormat.STRING);
            delete settings['Output File Info'];
            return { outputTemplates: om.templates, renderTemplates: rq.templates, extension: ext ? ext[0].toLowerCase() : null, outputSettings: settings, renderSettings: rq.getSettings(GetSettingsFormat.STRING) };
        } finally { if (rq) rq.remove(); try { app.project.renderQueue.showWindow(false); } catch (_) {} }
    }
    function comparablePath(file) {
        var value = String(file.fsName).replace(/\\/g, '/');
        if (/^[A-Za-z]:\//.test(value) || value.indexOf('//') === 0) value = value.toLowerCase();
        return value;
    }
    function destination(folder, output, extension) {
        if (!output || output.length > 160 || /[<>:"\/\\|?*\x00-\x1f\[\]#%]/.test(output) || /[. ]$/.test(output) || /^\s/.test(output) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(output)) throw new Error('Недопустимое имя output: ' + output);
        return new File(folder.fsName + '/' + output + extension);
    }
    function conflicts(file, scope, id) {
        if (file.exists) throw new Error('Файл уже существует: ' + file.fsName + '. Выберите новую папку вывода.');
        var queue = app.project.renderQueue;
        for (var i = 1; i <= queue.numItems; i++) {
            var q = queue.item(i); if (!q.render) continue;
            var m = meta(q.comp); if (m && m.scope === scope && m.record.id === id) continue;
            for (var j = 1; j <= q.numOutputModules; j++) {
                var other = q.outputModule(j).file;
                if (other && other.fsName.toLowerCase() === file.fsName.toLowerCase()) throw new Error('Этот путь уже занят в очереди: ' + file.fsName);
            }
        }
    }
    function settingsKey(args, info) {
        info = info || outputInfo(findComp(args.templateId), args.outputTemplate, args.renderTemplate);
        return encode([args.templateId, args.outputFolder, args.outputTemplate, args.renderTemplate, info.outputSettings, info.renderSettings]);
    }
    function pad2(n) { return n < 10 ? '0' + n : String(n); }
    function batchFolderName() {
        var d = new Date();
        return 'TF · ' + pad2(d.getDate()) + '.' + pad2(d.getMonth() + 1) + '.' + String(d.getFullYear()).substr(2) + '_' + pad2(d.getHours()) + '-' + pad2(d.getMinutes()) + '-' + pad2(d.getSeconds());
    }
    function preview(a) {
        requireProject(a.projectPath);
        var comp = findComp(a.templateId), t = Number(a.time), file;
        if (!isFinite(t) || t < comp.displayStartTime || t >= comp.displayStartTime + comp.duration) t = comp.time;
        if (!isFinite(t) || t < comp.displayStartTime || t >= comp.displayStartTime + comp.duration) t = comp.displayStartTime;
        file = new File(Folder.temp.fsName + '/titleflow-preview-' + comp.id + '-' + (new Date()).getTime() + '.png');
        comp.saveFrameToPng(t, file);
        if (!file.exists) throw new Error('After Effects не создал превью композиции.');
        return { path: file.fsName, time: t, width: comp.width, height: comp.height };
    }
    function nativeSetup(a) {
        requireProject(a.projectPath);
        var marker = 'TITLEFLOW_SETTINGS/1:' + a.templateId, scratch = null, q = null;
        for (var i = 1; i <= app.project.renderQueue.numItems; i++) {
            var item = app.project.renderQueue.item(i);
            if (item.comp.comment === marker) { q = item; scratch = item.comp; break; }
        }
        if (!q && a.capture) throw new Error('Сначала нажмите «Настроить кодек и альфа в AE» и настройте тестовое задание.');
        if (!q) {
            scratch = findComp(a.templateId).duplicate(); scratch.name = 'TF_SETTINGS · настройте Output Module'; scratch.comment = marker;
            try { q = app.project.renderQueue.items.add(scratch); q.render = false; }
            catch (e) { scratch.remove(); throw e; }
        }
        if (a.capture) {
            var name = 'TitleFlow Custom';
            q.outputModule(1).saveAsTemplate(name); q.saveAsTemplate(name);
            q.remove(); scratch.remove();
            return { outputTemplate: name, renderTemplate: name };
        }
        q.render = false;
        app.project.renderQueue.showWindow(true);
        return { message: 'В очереди откройте Output Module у TF_SETTINGS. Настройте формат, кодек и каналы. Затем вернитесь и нажмите «Забрать настройки из AE».', messageEn: 'Open Output Module for TF_SETTINGS in the queue. Configure format, codec, and channels, then return and click “Capture settings from AE”.' };
    }
    function begin(args) {
        requireProject(args.projectPath);
        if (session) throw new Error('Предыдущая операция ещё не завершена.');
        var comp = findComp(args.templateId), inspection = inspect(comp, args.layerMap), fields = args.fields && args.fields.length ? args.fields : FIELDS;
        if (meta(comp)) throw new Error('Выберите исходный шаблон, а не созданный титр.');
        if (inspection.errors.length) throw new Error(inspection.errors.join('\n'));
        var previous = latest(args.scope);
        if (signature(previous) !== args.baselineSignature) throw new Error('История проекта изменилась. Нажмите «Проверить данные» снова.');
        if (!args.rows || !args.rows.length || args.rows.length > 2000) throw new Error('Некорректный размер пакета.');
        if (!args.outputTemplate || !args.renderTemplate) throw new Error('Выберите Output Module и Render Settings.');
        var folder = new Folder(args.outputFolder); if (!folder.exists) throw new Error('Папка вывода не существует.');
        var info = outputInfo(comp, args.outputTemplate, args.renderTemplate);
        if (!info.extension) throw new Error('В первой версии поддерживаются видеофайлы MOV, MP4, AVI, MXF. Выберите соответствующий Output Module.');
        var ids = {}, paths = {};
        for (var i = 0; i < args.rows.length; i++) {
            var r = args.rows[i]; if (!r.id || ids['$' + r.id]) throw new Error('Пустой или повторный ID.'); ids['$' + r.id] = true;
            for (var f = 0; f < fields.length; f++) if (typeof r.data[fields[f]] !== 'string' || r.data[fields[f]].length > 2000) throw new Error('Некорректный текст у ID ' + r.id);
            var file = destination(folder, r.data.output, info.extension), path = '$' + file.fsName.toLowerCase();
            if (paths[path]) throw new Error('Повторяется путь вывода: ' + file.fsName); paths[path] = true;
            conflicts(file, args.scope, r.id);
        }
        if (args.settingsSignature !== settingsKey(args, info)) throw new Error('Настройки рендера изменились после проверки. Проверьте данные заново.');
        var batchFolder = app.project.items.addFolder(batchFolderName());
        session = { args: args, index: 0, extension: info.extension, previous: previous, folder: folder, batchFolder: batchFolder, settings: settingsKey(args, info) };
        return { total: args.rows.length, extension: info.extension, projectFolder: batchFolder.name };
    }
    function makeOne() {
        if (!session) throw new Error('Нет активного пакета.');
        var s = session, args = s.args, mappings = args.layerMap && args.layerMap.length ? args.layerMap : null; requireProject(args.projectPath);
        if (!mappings) { mappings = []; for (var mf = 0; mf < FIELDS.length; mf++) mappings.push({ layer: FIELDS[mf], field: FIELDS[mf] }); }
        if (s.index >= args.rows.length) throw new Error('Пакет уже завершён.');
        var record = args.rows[s.index], root = findComp(args.templateId), created = [], addedQueue = null, toggled = [];
        var file = destination(s.folder, record.data.output, s.extension); conflicts(file, args.scope, record.id);
        var revision = 1;
        for (var n = 0; n < s.previous.length; n++) if (s.previous[n].record.id === record.id) revision = s.previous[n].revision + 1;
        var metadata = { scope: args.scope, record: record, revision: revision, settings: s.settings, templateId: args.templateId };
        var comment = PREFIX + encode(metadata);
        if (encodeURIComponent(comment).replace(/%[0-9A-F]{2}/g, 'x').length > 15000) throw new Error('Слишком много текста для сохранения истории ID ' + record.id);
        app.beginUndoGroup('TitleFlow: ' + record.id);
        try {
            var copied = {};
            function duplicate(source) {
                var k = '$' + source.id; if (copied[k]) return copied[k];
                var dest = source.duplicate(); created.push(dest); copied[k] = dest; dest.parentFolder = s.batchFolder; dest.comment = 'TITLEFLOW_CHILD/1';
                dest.name = source === root ? record.data.output : source.name + ' · TF ' + record.id + ' v' + revision;
                for (var i = 1; i <= dest.numLayers; i++) {
                    var layer = dest.layer(i), sourceLayer = source.layer(i), oldName = sourceLayer.name, wasLocked = layer.locked;
                    layer.locked = false;
                    try {
                        if (sourceLayer.source instanceof CompItem) { layer.replaceSource(duplicate(sourceLayer.source), false); layer.name = oldName; }
                        for (var f = 0; f < mappings.length; f++) if (oldName === mappings[f].layer) {
                            var prop = layer.property('ADBE Text Properties').property('ADBE Text Document');
                            var document = prop.expressionEnabled ? prop.valueAtTime(dest.time, true) : prop.value;
                            document.text = record.data[mappings[f].field].replace(/\n/g, '\r'); prop.setValue(document); layer.name = oldName;
                        }
                    } finally { layer.locked = wasLocked; }
                }
                return dest;
            }
            var result = duplicate(root); result.comment = comment;
            addedQueue = app.project.renderQueue.items.add(result); addedQueue.render = false;
            addedQueue.applyTemplate(args.renderTemplate);
            addedQueue.outputModule(1).applyTemplate(args.outputTemplate);
            var om = addedQueue.outputModule(1); om.postRenderAction = PostRenderAction.NONE; om.file = file;
            var actualFile = addedQueue.outputModule(1).file;
            if (!actualFile || comparablePath(actualFile) !== comparablePath(file)) throw new Error('After Effects изменил путь вывода. Ожидалось: ' + file.fsName + '; получено: ' + (actualFile ? actualFile.fsName : '(пусто)') + '. Проверьте Output Module.');
            // Disable superseded pending jobs only after the replacement is fully ready.
            for (var q = 1; q <= app.project.renderQueue.numItems; q++) {
                var item = app.project.renderQueue.item(q); if (item === addedQueue || !item.render) continue;
                var m = meta(item.comp);
                if (m && m.scope === args.scope && m.record.id === record.id && item.status !== RQItemStatus.DONE) { toggled.push(item); item.render = false; }
            }
            addedQueue.render = true;
            s.index++;
            return { done: s.index, total: args.rows.length, id: record.id, compId: result.id, file: file.fsName };
        } catch (e) {
            if (addedQueue) try { addedQueue.remove(); } catch (_) {}
            for (var t = 0; t < toggled.length; t++) try { toggled[t].render = true; } catch (_) {}
            // Parents first: copied dependencies are no longer used when removed.
            for (var c = 0; c < created.length; c++) try { created[c].remove(); } catch (_) {}
            if (s.index === 0 && s.batchFolder) { try { s.batchFolder.remove(); } catch (_) {} s.batchFolder = null; }
            throw e;
        } finally { app.endUndoGroup(); }
    }
    function dispatch(request) {
        try {
            var a = decode(request), value;
            if (a.action === 'list') {
                requireProject(); var comps = [];
                for (var i = 1; i <= app.project.numItems; i++) { var c = app.project.item(i); if (c instanceof CompItem && !meta(c) && c.comment.indexOf('TITLEFLOW_SETTINGS/') !== 0 && c.comment.indexOf('TITLEFLOW_CHILD/') !== 0) comps.push({ id: c.id, name: c.name, folder: c.parentFolder.name }); }
                value = { projectPath: app.project.file.fsName, version: app.version, comps: comps };
            } else if (a.action === 'inspect') {
                requireProject(a.projectPath); value = inspect(findComp(a.templateId), a.layerMap);
            } else if (a.action === 'discover') {
                requireProject(a.projectPath); value = inspect(findComp(a.templateId), [], true);
            } else if (a.action === 'baseline') {
                requireProject(a.projectPath); var history = latest(a.scope); value = { items: history, signature: signature(history), settings: a.includeSettings === false ? null : settingsKey(a) };
            } else if (a.action === 'presets') { requireProject(a.projectPath); value = outputInfo(findComp(a.templateId), a.outputTemplate, a.renderTemplate); }
            else if (a.action === 'preview') value = preview(a);
            else if (a.action === 'nativeSetup') value = nativeSetup(a);
            else if (a.action === 'showQueue') { requireProject(a.projectPath); app.project.renderQueue.showWindow(true); value = true; }
            else if (a.action === 'disableRemoved') {
                requireProject(a.projectPath); var disabled = 0; app.beginUndoGroup('TitleFlow: исключить удалённые строки');
                try {
                    for (var qi = 1; qi <= app.project.renderQueue.numItems; qi++) {
                        var job = app.project.renderQueue.item(qi), jm = meta(job.comp);
                        if (!job.render || !jm || jm.scope !== a.scope || job.status === RQItemStatus.DONE) continue;
                        for (var ri = 0; ri < a.ids.length; ri++) if (a.ids[ri] === jm.record.id) { job.render = false; disabled++; break; }
                    }
                } finally { app.endUndoGroup(); }
                value = { disabled: disabled };
            }
            else if (a.action === 'folder') { var selected = Folder.selectDialog('Папка для готовых титров'); value = selected ? selected.fsName : null; }
            else if (a.action === 'begin') value = begin(a);
            else if (a.action === 'next') value = makeOne();
            else if (a.action === 'end') {
                value = { done: session ? session.index : 0 };
                if (session && session.index === 0 && session.batchFolder) try { session.batchFolder.remove(); } catch (_) {}
                session = null;
            }
            else throw new Error('Неизвестная команда.');
            return encode({ ok: true, value: value });
        } catch (e) { return encode({ ok: false, error: String(e.message || e) }); }
    }
    return { dispatch: dispatch };
}());
