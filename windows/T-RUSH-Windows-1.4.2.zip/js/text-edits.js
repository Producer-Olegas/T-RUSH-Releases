(function(root,factory){
  const api=factory(); if(typeof module==='object' && module.exports)module.exports=api;
  root.TitleFlowTextEdits=api;
}(typeof window!=='undefined'?window:this,function(){
  'use strict';
  const norm=value=>String(value==null?'':value).replace(/\r\n?/g,'\n');
  function clean(value){return norm(value).split('\n').map(line=>line.replace(/^[ \t]+|[ \t]+$/g,'').replace(/[ \t]+/g,' ')).join('\n');}
  const messages={
    quotes:['непарные кавычки — проверьте текст.','unpaired quotation marks — review the text.'],
    brackets:['непарные или перепутанные скобки — проверьте текст.','unpaired or mismatched brackets — review the text.'],
    trailing:['запятая или точка с запятой в конце текста.','a comma or semicolon at the end of the text.'],
    punctuation:['повторяющиеся знаки препинания.','repeated punctuation marks.'],
    spacing:['пробел рядом со знаком препинания — проверьте текст.','a space next to a punctuation mark — review the text.'],
    repeated:['повторяющееся слово — проверьте текст.','a repeated word — review the text.'],
    mixed:['похожие латинские и кириллические буквы в одном слове.','mixed Latin and Cyrillic letters in one word.'],
    invisible:['невидимые символы или табуляция — проверьте текст.','invisible characters or tabs — review the text.']
  };
  function issues(value){
    const text=norm(value),codes=[],stack=[];let bad=false;
    for(const c of text){if('([{'.includes(c))stack.push(c);else if(')]}'.includes(c)&&stack.pop()!=='([{'[')]}'.indexOf(c)])bad=true;}
    if(bad||stack.length)codes.push('brackets');
    const quotes=[];let badQuotes=false;
    for(const c of text){if(c==='«'||c==='“')quotes.push(c);else if(c==='»'||c==='”'){if(quotes.pop()!==(c==='»'?'«':'“'))badQuotes=true;}}
    if(badQuotes||quotes.length||(text.match(/"/g)||[]).length%2)codes.push('quotes');
    if(/[,;]\s*$/.test(text))codes.push('trailing');
    if(/\.{4,}/.test(text)||/,{2,}|;{2,}|\.{2}(?!\.)/.test(text.replace(/\.{3}/g,'')))codes.push('punctuation');
    if(/ +[,.;:!?\)\]\}»]|[\(\[\{«] +/.test(text.replace(/\.{3}|…/g,'ELLIPSIS')))codes.push('spacing');
    const words=text.match(/[A-Za-zА-Яа-яЁё]+/g)||[];
    if(words.some((word,i)=>i&&word.toLowerCase()===words[i-1].toLowerCase()))codes.push('repeated');
    if(words.some(word=>/[A-Za-z]/.test(word)&&/[А-Яа-яЁё]/.test(word)))codes.push('mixed');
    if(/[\t\u200b-\u200d\ufeff]/.test(text))codes.push('invisible');
    return codes.map(code=>({code,ru:messages[code][0],en:messages[code][1]}));
  }
  function create(saved){
    let patches=Array.isArray(saved&&saved.patches)?saved.patches.filter(p=>p&&typeof p.scope==='string'&&typeof p.id==='string'&&typeof p.field==='string'&&p.field!=='output'&&typeof p.base==='string'&&typeof p.value==='string'):[],undo=[],revision=0,versions=new Map();
    const find=(scope,id,field)=>patches.find(p=>p.scope===scope&&p.id===String(id)&&p.field===field);
    function set(scope,id,field,base,value){
      if(field==='output')return null;
      const before=find(scope,id,field);versions.set(JSON.stringify([scope,String(id),field]),++revision);patches=patches.filter(p=>p!==before);base=norm(base);value=norm(value);
      if(value!==base){const entry={scope,id:String(id),field,base,value,revision:revision};patches.push(entry);return entry;}
      return null;
    }
    function apply(matrix,scope,fields){
      const out=matrix.map(row=>row.slice()),headers=(matrix[0]||[]).map(v=>String(v).trim()),idIndex=headers.indexOf('number'),conflicts=[],applied=[];
      if(idIndex<0)return {matrix:out,conflicts,applied};
      const counts=new Map();matrix.slice(1).forEach(row=>{const id=String(row[idIndex]||'').trim();counts.set(id,(counts.get(id)||0)+1);});
      matrix.slice(1).forEach((row,i)=>{const id=String(row[idIndex]||'').trim();if(!id||counts.get(id)!==1)return;
        fields.forEach(field=>{const p=find(scope,id,field),col=headers.indexOf(field);if(!p||col<0)return;
          const raw=norm(row[col]);if(raw!==p.base&&raw!==p.value){conflicts.push({id,field,row:i+2,local:p.value,source:raw});return;}
          out[i+1][col]=p.value;applied.push({id,field,row:i+2});
        });
      });return {matrix:out,conflicts,applied};
    }
    function plan(matrix,scope,fields){
      const result=apply(matrix,scope,fields),headers=(matrix[0]||[]).map(v=>String(v).trim()),idIndex=headers.indexOf('number'),changes=[];
      if(result.conflicts.length||idIndex<0)return changes;
      result.matrix.slice(1).forEach((row,i)=>{const id=String(row[idIndex]||'').trim();if(!id||matrix.slice(1).filter(other=>String(other[idIndex]||'').trim()===id).length!==1)return;
        fields.filter(field=>field!=='output').forEach(field=>{const col=headers.indexOf(field);if(col<0)return;const before=norm(row[col]),after=clean(before);
          if(before!==after)changes.push({id,field,row:i+2,base:norm(matrix[i+1][col]),before,after});
        });
      });return changes;
    }
    return {apply,plan,set,issues,clean,
      get:(scope,id,field)=>find(scope,id,field),
      has:(scope,id)=>patches.some(p=>p.scope===scope&&p.id===String(id)),
      reset(scope,id){patches.filter(p=>p.scope===scope&&p.id===String(id)).forEach(p=>versions.set(JSON.stringify([scope,String(id),p.field]),++revision));patches=patches.filter(p=>p.scope!==scope||p.id!==String(id));},
      auto(scope,changes){undo=changes.map(c=>{const old=find(scope,c.id,c.field);const before=old?Object.assign({},old):null;const after=set(scope,c.id,c.field,c.base,c.after);return {scope,id:c.id,field:c.field,before,after,version:versions.get(JSON.stringify([scope,String(c.id),c.field]))};});},
      canUndo:scope=>undo.some(item=>item.scope===scope),
      undo(scope){for(const item of undo.filter(item=>item.scope===scope)){const current=find(item.scope,item.id,item.field);if(current!==item.after||versions.get(JSON.stringify([item.scope,String(item.id),item.field]))!==item.version)continue;patches=patches.filter(p=>p!==current);if(item.before)patches.push(item.before);}undo=undo.filter(item=>item.scope!==scope);},
      serialize:()=>({patches:patches.map(p=>Object.assign({},p))})
    };
  }
  return {create,clean,issues,messages};
}));
