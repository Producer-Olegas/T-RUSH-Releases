(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.TitleFlowCore = api;
}(typeof window !== 'undefined' ? window : this, function () {
  'use strict';
  var FIELDS = ['name_ru', 'name_en', 'work_ru', 'work_en', 'output'];
  function norm(v) { return String(v == null ? '' : v).replace(/\r\n?/g, '\n'); }
  function key(v) { return norm(v).trim(); }
  function canon(v) { return v.normalize ? v.normalize('NFC').toLowerCase() : v.toLowerCase(); }
  function parseCSV(text, delimiter) {
    text = norm(text).replace(/^\uFEFF/, '');
    if (!delimiter) {
      var counts = { ',': 0, ';': 0, '\t': 0 }, quoted = false;
      for (var n = 0; n < text.length; n++) {
        var x = text[n];
        if (x === '"') { if (quoted && text[n + 1] === '"') n++; else quoted = !quoted; }
        else if (!quoted && x === '\n') break;
        else if (!quoted && counts[x] !== undefined) counts[x]++;
      }
      delimiter = Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a]; })[0];
    }
    var rows = [], row = [], cell = '', inside = false, closed = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (inside) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else { inside = false; closed = true; } }
        else cell += c;
      } else if (c === delimiter || c === '\n') {
        row.push(cell); cell = ''; closed = false;
        if (c === '\n') { rows.push(row); row = []; }
      } else if (c === '"' && !cell && !closed) inside = true;
      else {
        if (closed || c === '"') throw new Error('Некорректные кавычки в CSV, запись ' + (rows.length + 1));
        cell += c;
      }
    }
    if (inside) throw new Error('В CSV не закрыта кавычка.');
    if (cell || row.length || closed) { row.push(cell); rows.push(row); }
    return rows;
  }
  function filenameError(name) {
    if (!name) return 'Пустой output.';
    if (/[<>:"/\\|?*\x00-\x1f]/.test(name)) return 'В output есть недопустимые символы для имени файла.';
    if (/[. ]$/.test(name) || name === '.' || name === '..') return 'output заканчивается точкой или пробелом.';
    if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name)) return 'output содержит зарезервированное имя Windows.';
    if (name.length > 160) return 'output длиннее 160 символов.';
    if (encodeURIComponent(name).replace(/%[0-9A-F]{2}/g, 'x').length > 230) return 'output слишком длинный для имени файла в UTF-8.';
    if (/\.(mov|mp4|avi|mxf|mkv|png|jpg|exr)$/i.test(name)) return 'Укажите output без расширения: оно берётся из Output Module.';
    if (/[\[\]#%]/.test(name)) return 'Уберите из output символы шаблона имени файла: [ ] # %.';
    return null;
  }
  function validate(matrix, options) {
    options = options || {};
    var textFields = options.fields && options.fields.length ? options.fields.slice() : FIELDS.slice(0, 4);
    var dataFields = textFields.concat(['output']);
    var errors = [], warnings = [], rows = [], skipped = 0;
    var idColumn = options.idColumn || 'number';
    if (!matrix.length) return { rows: [], errors: [{ row: 1, message: 'Таблица пуста.' }], warnings: [], skipped: 0 };
    var headers = matrix[0].map(key), indexes = Object.create(null);
    headers.forEach(function (h, i) {
      if (!h) return;
      if (indexes[h] !== undefined) errors.push({ row: 1, message: 'Повторяется заголовок ' + h });
      indexes[h] = i;
    });
    dataFields.concat([idColumn]).forEach(function (f) {
      if (indexes[f] === undefined) errors.push({ row: 1, message: 'Нет столбца ' + f });
    });
    if (errors.length) return { rows: rows, errors: errors, warnings: warnings, skipped: skipped };
    var ids = Object.create(null), outputs = Object.create(null);
    matrix.slice(1).forEach(function (cells, offset) {
      var rowNumber = offset + 2;
      if (cells.every(function (v) { return !key(v); })) return;
      // Templates often pre-fill numbers and formulas hundreds of rows ahead.
      if (textFields.every(function (f) { return !key(cells[indexes[f]]); })) { skipped++; return; }
      if (indexes.enabled !== undefined && /^(0|false|no|нет)$/i.test(key(cells[indexes.enabled]))) { skipped++; return; }
      var id = key(cells[indexes[idColumn]]);
      if (/^(пример|example)$/i.test(id)) { skipped++; return; }
      var record = { id: id, row: rowNumber, data: {} };
      if (!id) errors.push({ row: rowNumber, message: 'Нет постоянного ID в ' + idColumn });
      else if (ids[id]) errors.push({ row: rowNumber, message: 'ID ' + id + ' уже встречается в строке ' + ids[id] });
      ids[id] = rowNumber;
      dataFields.forEach(function (f) { record.data[f] = norm(cells[indexes[f]]); });
      dataFields.forEach(function (f) {
        if (/^#(?:REF!|ERROR!|VALUE!|N\/A|DIV\/0!|NAME\?|NUM!|NULL!|ССЫЛКА!|ЗНАЧ!|ДЕЛ\/0!|Н\/Д|ИМЯ\?|ЧИСЛО!)/i.test(record.data[f])) errors.push({ row: rowNumber, message: f + ': в ячейке ошибка формулы ' + record.data[f] });
      });
      if (options.safeOutput && record.data.output) {
        record.data.output = safeOutput(record.data.output);
      }
      if (options.cleanOutput) {
        var cleaned = record.data.output.replace(/[\t\n]+/g, ' ').trim();
        if (cleaned !== record.data.output) warnings.push({ row: rowNumber, message: 'Имя файла очищено от табуляции и переносов: ' + cleaned });
        record.data.output = cleaned;
      }
      if (record.data.output !== record.data.output.trim()) errors.push({ row: rowNumber, message: 'В начале или конце output есть пробелы.' });
      var error = filenameError(record.data.output);
      if (error) errors.push({ row: rowNumber, message: error });
      var fileKey = canon(record.data.output);
      if (outputs[fileKey]) errors.push({ row: rowNumber, message: 'Повторяется output из строки ' + outputs[fileKey] + ' (без учёта регистра).' });
      outputs[fileKey] = rowNumber;
      textFields.forEach(function (f) {
        if (/\t| {2,}|\u00a0/.test(record.data[f]) || record.data[f] !== record.data[f].trim()) warnings.push({ row: rowNumber, message: f + ': лишние пробелы, табуляция или пробел/перенос на краю текста; проверьте вёрстку.' });
        if (!key(record.data[f])) warnings.push({ row: rowNumber, message: 'Пустое поле ' + f + ' — соответствующий слой будет очищен.' });
        if (record.data[f].length > 180) warnings.push({ row: rowNumber, message: f + ': длинный текст, проверьте вёрстку.' });
        if (record.data[f].length > 2000) errors.push({ row: rowNumber, message: f + ': более 2000 символов.' });
      });
      if (id.length > 80) errors.push({ row: rowNumber, message: 'ID длиннее 80 символов.' });
      rows.push(record);
    });
    if (!rows.length) errors.push({ row: 1, message: 'Нет активных записей для обработки.' });
    if (rows.length > 2000) errors.push({ row: 1, message: 'Более 2000 титров: разбейте на несколько листов.' });
    return { rows: rows, errors: errors, warnings: warnings, skipped: skipped };
  }
  function safeOutput(value) {
    var result = norm(value).replace(/[<>:"/\\|?*\x00-\x1f\[\]#%]/g, '_').trim().replace(/[. ]+$/, '_');
    if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(result)) result = '_' + result;
    var chars = Array.from(result);
    while (result.length > 160 || encodeURIComponent(result).replace(/%[0-9A-F]{2}/g, 'x').length > 230) { chars.pop(); result = chars.join(''); }
    return result.replace(/[. ]+$/, '');
  }
  function diff(rows, baseline, fields) {
    fields = fields && fields.length ? fields.concat(['output']) : FIELDS;
    var old = Object.create(null), current = Object.create(null), result = [];
    baseline.forEach(function (r) { old[r.id] = r; });
    rows.forEach(function (r) {
      current[r.id] = true;
      var previous = old[r.id];
      if (!previous) result.push({ type: 'added', record: r, changes: [] });
      else {
        var changes = [];
        fields.forEach(function (f) {
          if (norm(previous.data[f]) !== r.data[f]) changes.push({ field: f, before: norm(previous.data[f]), after: r.data[f] });
        });
        result.push({ type: changes.length ? 'changed' : 'same', record: r, changes: changes });
      }
    });
    baseline.forEach(function (r) { if (!current[r.id]) result.push({ type: 'removed', record: r, changes: [] }); });
    return result;
  }
  function sheetRef(url, tab) {
    var source = String(url), match = source.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
    var id = match ? match[1] : key(url);
    var gidMatch = source.match(/[?#&]gid=(\d+)/);
    if (!/^[a-zA-Z0-9_-]{20,}$/.test(id)) throw new Error('Вставьте ссылку на Google-таблицу или её ID.');
    if (!key(tab)) throw new Error('Укажите название вкладки таблицы.');
    return { id: id, tab: tab, gid: gidMatch ? gidMatch[1] : null, range: "'" + tab.replace(/'/g, "''") + "'!A1:AZ2002" };
  }
  return { fields: FIELDS, parseCSV: parseCSV, validate: validate, diff: diff, filenameError: filenameError, safeOutput: safeOutput, sheetRef: sheetRef };
}));
