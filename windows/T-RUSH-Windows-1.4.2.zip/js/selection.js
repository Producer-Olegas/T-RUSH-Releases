(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.TitleFlowSelection = api;
}(typeof window !== 'undefined' ? window : this, function () {
  'use strict';
  function create() {
    let scope = null, entries = new Map();
    return {
      reconcile(rows, validRows, nextScope) {
        const previous = nextScope === scope ? entries : new Map();
        entries = new Map(rows.map(record => {
          const id = String(record.id), eligible = !!validRows[record.row];
          return [id, { record, eligible, selected: eligible && (previous.has(id) ? previous.get(id).selected : true) }];
        }));
        scope = nextScope;
      },
      set(id, selected) {
        const entry = entries.get(String(id));
        if (entry && entry.eligible) entry.selected = !!selected;
      },
      setAll(selected) { entries.forEach(entry => { entry.selected = entry.eligible && !!selected; }); },
      has(id) { const entry = entries.get(String(id)); return !!(entry && entry.eligible && entry.selected); },
      eligible(id) { const entry = entries.get(String(id)); return !!(entry && entry.eligible); },
      records() { return Array.from(entries.values()).filter(entry => entry.eligible && entry.selected).map(entry => entry.record); },
      counts() {
        const all = Array.from(entries.values());
        return { selected: all.filter(entry => entry.eligible && entry.selected).length, eligible: all.filter(entry => entry.eligible).length, total: all.length };
      }
    };
  }
  return { create };
}));
