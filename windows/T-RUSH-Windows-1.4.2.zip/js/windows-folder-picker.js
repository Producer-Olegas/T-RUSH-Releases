'use strict';
const cp = require('child_process'), path = require('path'), fs = require('fs');
function createPicker(deps) {
  deps = deps || {};
  const run = deps.execFile || cp.execFile;
  return function pick(options) {
    options = options || {};
    const shell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32/WindowsPowerShell/v1.0/powershell.exe');
    const helper = path.join(__dirname, '../updater/folder-picker.ps1');
    return new Promise((resolve, reject) => {
      const child = run(shell, ['-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'Bypass', '-File', helper],
        {windowsHide:true, encoding:'utf8', maxBuffer:65536}, (error, stdout) => {
          if (error) { reject(new Error('Windows Folder Picker: ' + error.message)); return; }
          try {
            const result = JSON.parse(String(stdout).replace(/^\uFEFF/, '').trim());
            if (!result.ok) throw new Error(result.error || 'Unknown picker error');
            if (result.cancelled) { resolve(null); return; }
            if (typeof result.path !== 'string' || !path.win32.isAbsolute(result.path)) throw new Error('Invalid folder path');
            const stat = (deps.statSync || fs.statSync)(result.path);
            if (!stat.isDirectory()) throw new Error('Selected path is not a folder');
            resolve(result.path);
          } catch (e) { reject(new Error('Windows Folder Picker: ' + e.message)); }
        });
      // Paths and localized titles are data on stdin, never interpolated shell commands.
      child.stdin.on('error', () => {});
      child.stdin.end(JSON.stringify({initialFolder:options.initialFolder || '', title:options.title || 'T-RUSH'}));
    });
  };
}
module.exports = {pick:createPicker(), createPicker};
