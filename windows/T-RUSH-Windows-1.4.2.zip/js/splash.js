(function () {
  'use strict';
  const splash = document.getElementById('splash');
  if (!splash) return;
  const fallback = splash.querySelector('img');
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 460;
  canvas.hidden = true;
  canvas.setAttribute('aria-hidden', 'true');
  fallback.parentNode.insertBefore(canvas, fallback);
  const ctx = canvas.getContext('2d');
  const image = new Image();
  let ready = false, started = false, run = 0;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  function draw(frame) {
    ctx.clearRect(0, 0, 460, 460);
    ctx.drawImage(image, frame % 10 * 460, Math.floor(frame / 10) * 460, 460, 460, 0, 0, 460, 460);
    canvas.dataset.frame = String(frame);
  }
  function play() {
    started = true;
    const id = ++run;
    splash.style.animation = 'none';
    void splash.offsetWidth;
    splash.style.animation = '';
    splash.style.animationPlayState = 'running';
    if (!ready) { canvas.hidden = true; fallback.hidden = false; return; }
    // Paint before exposing the canvas; both layers occupy the same fixed slot.
    draw(reducedMotion.matches ? 59 : 0);
    canvas.hidden = false;
    fallback.hidden = true;
    if (reducedMotion.matches) return;
    let start = null;
    function step(now) {
      if (id !== run) return;
      if (start === null) start = now;
      const elapsed = now - start;
      draw(Math.min(59, Math.floor(elapsed * 30 / 1000)));
      if (elapsed < 2000) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  image.onload = function () {
    if (ctx && image.naturalWidth === 4600 && image.naturalHeight === 2760) ready = true;
    if (!started) play();
  };
  image.onerror = function () { if (!started) play(); };
  image.src = 'assets/t-rush-splash.png';
  // Never hold the panel open indefinitely if the animation cannot be decoded.
  setTimeout(function () { if (!started) play(); }, 1500);
  const replay = document.getElementById('replaySplash');
  if (replay) replay.addEventListener('click', play);
}());
