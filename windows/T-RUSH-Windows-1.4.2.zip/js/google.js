'use strict';
// Runs in CEP's bundled Node runtime. No third-party packages or stored tokens.
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const URL = require('url').URL;
const qs = require('querystring');

function request(url, options, body) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:' || !['sheets.googleapis.com', 'oauth2.googleapis.com'].includes(parsed.hostname)) return reject(new Error('Недопустимый адрес Google API.'));
    const req = https.request(url, options || {}, res => {
      const chunks = []; let size = 0;
      res.on('data', chunk => { size += chunk.length; if (size > 8 * 1024 * 1024) req.destroy(new Error('Ответ превышает 8 МБ.')); else chunks.push(chunk); });
      res.on('error', reject);
      res.on('end', () => {
        let data;
        try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (_) { return reject(new Error('Google вернул некорректный ответ.')); }
        if (res.statusCode < 200 || res.statusCode >= 300) {
          const e = new Error('Google API ' + res.statusCode + ': ' + (data.error_description || (data.error && data.error.message) || data.error || 'ошибка запроса'));
          e.status = res.statusCode; return reject(e);
        }
        resolve(data);
      });
    });
    req.setTimeout(30000, () => req.destroy(new Error('Google не отвечает. Проверьте сеть.')));
    req.on('error', reject); if (body) req.write(body); req.end();
  });
}

function requestText(url, redirects, allowHtml) {
  redirects = redirects || 0;
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(url); } catch (_) { return reject(new Error('Некорректная ссылка Google Sheets.')); }
    const allowed = parsed.hostname === 'docs.google.com' || /\.googleusercontent\.com$/.test(parsed.hostname);
    if (parsed.protocol !== 'https:' || !allowed) return reject(new Error('Google перенаправил запрос на недопустимый адрес.'));
    const req = https.get(url, { headers: { 'User-Agent': 'TitleFlow/0.1', Accept: 'text/csv' } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        if (redirects >= 5) return reject(new Error('Слишком много перенаправлений Google.'));
        return requestText(new URL(res.headers.location, parsed).toString(), redirects + 1, allowHtml).then(resolve, reject);
      }
      const chunks = []; let size = 0;
      res.on('data', chunk => { size += chunk.length; if (size > 8 * 1024 * 1024) req.destroy(new Error('Таблица превышает 8 МБ.')); else chunks.push(chunk); });
      res.on('error', reject);
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        if (res.statusCode < 200 || res.statusCode >= 300) return reject(new Error('Google Sheets вернул ошибку ' + res.statusCode + '. Проверьте доступ по ссылке.'));
        if (!allowHtml && /<!doctype html|<html/i.test(text)) return reject(new Error('Таблица недоступна без входа. Включите «Все, у кого есть ссылка → Читатель».'));
        resolve(text);
      });
    });
    req.setTimeout(30000, () => req.destroy(new Error('Google не отвечает. Проверьте сеть.')));
    req.on('error', reject);
  });
}
function tokenRequest(fields) {
  const body = qs.stringify(fields);
  return request('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body) } }, body);
}
function b64(buffer) { return buffer.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
function parsePublicSheets(page) {
  const result = [], seen = {}, pattern = /\[21350203,("(?:\\.|[^"\\])*")\]/g;
  let match;
  while ((match = pattern.exec(page))) {
    try {
      const payload = JSON.parse(match[1]), metadata = JSON.parse(payload);
      const gid = String(metadata[2]), title = metadata[3][0]['1'][0][2];
      if (/^\d+$/.test(gid) && typeof title === 'string' && !seen[gid]) { seen[gid] = true; result.push({ title, gid }); }
    } catch (_) {}
  }
  return result;
}
function createClient() {
  let credentials = null, token = null, cancelPending = null;
  function configure(json) {
    if (!json.installed || !json.installed.client_id) throw new Error('Нужен OAuth JSON типа Desktop app (поле installed).');
    credentials = { client_id: json.installed.client_id, client_secret: json.installed.client_secret || '' };
    token = null;
  }
  function acceptTokens(data) {
    if (!data.access_token) throw new Error('Google не вернул токен доступа.');
    token = { access: data.access_token, refresh: data.refresh_token || (token && token.refresh), expires: Date.now() + Number(data.expires_in || 3600) * 1000 };
  }
  function login(openBrowser) {
    if (!credentials) return Promise.reject(new Error('Сначала выберите OAuth JSON.'));
    if (cancelPending) return Promise.reject(new Error('Вход уже выполняется.'));
    return new Promise((resolve, reject) => {
      const state = b64(crypto.randomBytes(24)), verifier = b64(crypto.randomBytes(48));
      const challenge = b64(crypto.createHash('sha256').update(verifier).digest());
      let finished = false, redirect, timer;
      function finish(error, data) {
        if (finished) return; finished = true; clearTimeout(timer); server.close(); cancelPending = null;
        if (error) reject(error); else { try { acceptTokens(data); resolve(true); } catch (e) { reject(e); } }
      }
      const server = http.createServer((req, res) => {
        const url = new URL(req.url, redirect || 'http://127.0.0.1');
        res.setHeader('Cache-Control', 'no-store'); res.setHeader('Content-Type', 'text/plain; charset=utf-8');
        if (req.method !== 'GET' || url.pathname !== '/oauth/callback') { res.statusCode = 404; res.end('Not found'); return; }
        if (url.searchParams.get('state') !== state) { res.statusCode = 400; res.end('Invalid state'); return; }
        if (url.searchParams.get('error')) { res.end('Вход отменён. Вернитесь в TitleFlow.'); finish(new Error('Вход в Google отменён.')); return; }
        const code = url.searchParams.get('code');
        if (!code) { res.statusCode = 400; res.end('Missing code'); return; }
        res.end('Ответ Google получен. Вернитесь в панель TitleFlow в After Effects.');
        tokenRequest(Object.assign({}, credentials, { code, code_verifier: verifier, redirect_uri: redirect, grant_type: 'authorization_code' })).then(data => finish(null, data), finish);
      });
      server.timeout = 10000;
      server.on('error', finish);
      cancelPending = () => finish(new Error('Вход отменён.'));
      timer = setTimeout(() => finish(new Error('Время входа истекло. Нажмите «Войти в Google» снова.')), 180000);
      server.listen(0, '127.0.0.1', () => {
        redirect = 'http://127.0.0.1:' + server.address().port + '/oauth/callback';
        const url = 'https://accounts.google.com/o/oauth2/v2/auth?' + qs.stringify({ client_id: credentials.client_id, redirect_uri: redirect, response_type: 'code', scope: 'https://www.googleapis.com/auth/spreadsheets.readonly', state, code_challenge: challenge, code_challenge_method: 'S256', access_type: 'offline', prompt: 'consent' });
        try { openBrowser(url); } catch (e) { finish(e); }
      });
    });
  }
  async function authorize() {
    if (!token) throw new Error('Сначала войдите в Google.');
    if (token.expires < Date.now() + 60000) {
      if (!token.refresh) throw new Error('Сеанс истёк. Войдите снова.');
      acceptTokens(await tokenRequest(Object.assign({}, credentials, { refresh_token: token.refresh, grant_type: 'refresh_token' })));
    }
  }
  async function api(path) {
    await authorize();
    return request('https://sheets.googleapis.com/v4/spreadsheets/' + path, { headers: { Authorization: 'Bearer ' + token.access } });
  }
  async function read(id, range) {
    const data = await api(encodeURIComponent(id) + '/values/' + encodeURIComponent(range) + '?valueRenderOption=FORMATTED_VALUE&majorDimension=ROWS');
    return data.values || [];
  }
  async function readSheet(id, tab) {
    const meta = await api(encodeURIComponent(id) + '?fields=sheets(properties(title,gridProperties(rowCount,columnCount)))');
    const sheet = (meta.sheets || []).map(s => s.properties).find(s => s.title === tab);
    if (!sheet) throw new Error('Вкладка «' + tab + '» не найдена. Проверьте название.');
    const grid = sheet.gridProperties;
    if (!grid || grid.rowCount > 10000) throw new Error('Вкладка слишком большая. Используйте отдельный лист до 10 000 строк.');
    const columns = Math.min(grid.columnCount, 52);
    const last = columns <= 26 ? String.fromCharCode(64 + columns) : 'A' + String.fromCharCode(64 + columns - 26);
    return read(id, "'" + tab.replace(/'/g, "''") + "'!A1:" + last + grid.rowCount);
  }
  function logout() { if (cancelPending) cancelPending(); token = null; }
  async function readPublicSheet(id, tab, gid) {
    if (!/^[A-Za-z0-9_-]{20,}$/.test(id)) return Promise.reject(new Error('Некорректный ID таблицы.'));
    if (!tab || tab.length > 200) return Promise.reject(new Error('Укажите название вкладки.'));
    if (gid && !/^\d+$/.test(String(gid))) throw new Error('Некорректный gid вкладки.');
    if (!gid) {
      const page = await requestText('https://docs.google.com/spreadsheets/d/' + encodeURIComponent(id) + '/edit?usp=sharing', 0, true);
      const match = page.match(/id="(\d+)-grid-container"/);
      if (!match) throw new Error('Не удалось определить вкладку. Откройте нужную вкладку в Google Sheets и скопируйте ссылку с #gid=.');
      gid = match[1];
    }
    const url = 'https://docs.google.com/spreadsheets/d/' + encodeURIComponent(id) + '/export?format=csv&gid=' + encodeURIComponent(gid);
    return requestText(url);
  }
  async function listPublicSheets(id) {
    if (!/^[A-Za-z0-9_-]{20,}$/.test(id)) throw new Error('Некорректный ID таблицы.');
    const page = await requestText('https://docs.google.com/spreadsheets/d/' + encodeURIComponent(id) + '/edit?usp=sharing', 0, true);
    const result = parsePublicSheets(page);
    if (!result.length) {
      const gid = (page.match(/id="(\d+)-grid-container"/) || [])[1];
      const title = (page.match(/docs-sheet-tab-caption">([^<]+)</) || [])[1];
      if (gid && title) result.push({ title, gid });
    }
    if (!result.length) throw new Error('Не удалось получить список вкладок. Проверьте публичный доступ к таблице.');
    return result;
  }
  return { configure, login, read, readSheet, readPublicSheet, listPublicSheets, logout };
}
module.exports = { createClient, parsePublicSheets };
