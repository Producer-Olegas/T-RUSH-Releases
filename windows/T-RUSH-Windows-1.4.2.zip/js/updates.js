(function () {
 'use strict';
 const button=document.getElementById('checkUpdates');if(!button)return;
 const diagnostic=document.createElement('small');diagnostic.id='updateDiagnostic';diagnostic.style.cssText='color:#ffb21c;font-size:11px;max-width:220px;overflow-wrap:anywhere';button.parentNode.insertBefore(diagnostic,button.nextSibling);
 let update=null,client=null,base=null,working=false,state='checking';
 function label(ru,en){return document.documentElement.lang==='en'?en:ru;}
 function render(){
   button.hidden=state==='current';
   button.disabled=working||state==='staged';button.style.cursor=button.disabled?'default':'pointer';
   button.classList.add('update-available');
   const labels={checking:label('Проверка обновлений…','Checking updates…'),available:label('Обновить до ','Update to ')+(update?update.version:''),loading:label('Загрузка обновления…','Preparing update…'),staged:label('Закройте AE для установки','Quit AE to install'),unavailable:label('Обновления: ошибка проверки','Updates: check failed'),error:label('Повторить обновление','Retry update')};
   button.textContent=labels[state]||'';
 }
 async function check(){working=true;render();try{update=await client.check('1.4.2');state=update?'available':'current';}catch(error){state='unavailable';button.title=error.message;document.getElementById('updateDiagnostic').textContent=error.message;}finally{working=false;render();}}
 button.onclick=async()=>{if(working||state==='staged')return;if(!client)return;if(!update){check();return;}working=true;state='loading';diagnostic.textContent='';button.title='';render();try{await client.prepare(update,base);state='staged';}catch(error){state='error';button.title=error.message;diagnostic.textContent=error.message;}finally{working=false;render();}};
 new MutationObserver(render).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
 render();
 try{if(!window.__adobe_cep__)throw new Error('CEP bridge unavailable');if(!window.cep_node)throw new Error('CEP Node unavailable');base=decodeURI(window.__adobe_cep__.getSystemPath('extension').replace(/^file:\/\//,''));if(/^\/[A-Za-z]:/.test(base))base=base.slice(1);const platform=window.cep_node.require('os').platform();if(platform!=='darwin'&&platform!=='win32')throw new Error('Unsupported update platform');client=window.cep_node.require(base+(platform==='win32'?'/updater/windows-client.js':'/updater/client.js'));check();}catch(error){state='unavailable';button.title=error.message;diagnostic.textContent=error.message;render();}
}());
