(function () {
  'use strict';
  const C = window.TitleFlowCore, $ = id => document.getElementById(id);
  const demo = new URLSearchParams(location.search).get('demo') === '1';
  const cep = window.__adobe_cep__;
  const titleSelection = window.TitleFlowSelection.create();
  let editState = null;
  try { editState = JSON.parse(localStorage.getItem('trush.textEdits') || 'null'); } catch (_) {}
  const textEdits = window.TitleFlowTextEdits.create(editState);
  function persistTextEdits() { try { localStorage.setItem('trush.textEdits', JSON.stringify(textEdits.serialize())); } catch (_) { status('Не удалось сохранить локальные правки. Не закрывайте панель до подготовки.', true, 'Local edits could not be saved. Keep the panel open until preparation finishes.'); } }

  let google = null, project = null, checked = null, busy = false, cancelled = false, csv = null, reviewApproved = false, templateDiscovery = null, templateSchema = null, currentLang = 'ru', lastStatus = { ru: 'Готов к подключению.', en: 'Ready to connect.', error: false };
  let sourceSnapshot = null;
  try {
    const parsedSnapshot = JSON.parse(localStorage.getItem('titleflow.sourceSnapshot') || 'null');
    if (parsedSnapshot && typeof parsedSnapshot.key === 'string' && Array.isArray(parsedSnapshot.rows)) sourceSnapshot = parsedSnapshot;
  } catch (_) {}
  const savedFields = ['sourceMode', 'dataset', 'template', 'renderTemplate', 'outputTemplate', 'outputFolder', 'cleanOutput'];
  const defaults = { dataset: 'Титры_Предзаписи' };
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem('titleflow.settings') || '{}'); } catch (_) {}
  saved = Object.assign({}, defaults, saved);
  savedFields.forEach(id => { if (saved[id] !== undefined) { if ($(id).type === 'checkbox') $(id).checked = saved[id]; else if ($(id).tagName !== 'SELECT') $(id).value = saved[id]; } });
  if (saved.sourceMode && !demo) $('sourceMode').value = saved.sourceMode;
  $('sheetUrl').value = '';
  if (demo) { $('sourceMode').value = 'demo'; $('demoBanner').hidden = false; $('connection').textContent = 'Демо'; }
  function t(ru, en) { return currentLang === 'en' ? en : ru; }
  function localizedText(el, ru, en) {
    el.dataset.ru = ru; el.dataset.en = en; el.textContent = t(ru, en); return el;
  }
  function pluralRu(n, one, few, many) { const a = Math.abs(n) % 100, b = a % 10; return a > 10 && a < 20 ? many : b === 1 ? one : b >= 2 && b <= 4 ? few : many; }
  function issueCountLabel(errors, warnings) { return currentLang === 'en' ? errors + ' errors · ' + warnings + ' warnings' : errors + ' ' + pluralRu(errors, 'ошибка', 'ошибки', 'ошибок') + ' · ' + warnings + ' ' + pluralRu(warnings, 'замечание', 'замечания', 'замечаний'); }
  function status(ru, error, en) { lastStatus = { ru: ru, en: en || ru, error: !!error }; $('status').textContent = t(lastStatus.ru, lastStatus.en); $('status').className = error ? 'error' : ''; }
  function nav(name) { return document.querySelector('.nav[data-screen="' + name + '"]'); }
  function workflow(name, ready, value) {
    const badge = $(name + 'Badge');
    if (badge) { badge.textContent = ready ? (value || '✓') : '—'; badge.classList.toggle('warn', name === 'review' && ready && value !== '✓'); }
  }
  function screen(name) {
    document.querySelectorAll('.screen').forEach(el => el.classList.toggle('active', el.id === 'screen-' + name));
    document.querySelectorAll('.nav').forEach(el => el.classList.toggle('active', el.dataset.screen === name));
  }
  const translations = {
    'РАБОЧИЙ ПРОЦЕСС':'WORKFLOW','Источник':'Source','Шаблон':'Template','Проверка':'Review','Рендер':'Render',
    'Исправные строки можно подготовить одним пакетом. Строки с ошибками будут пропущены.':'Valid rows can be prepared as one batch. Rows with errors will be skipped.',
    'нужна ссылка':'link required','● доступна':'● available','ССЫЛКА НА ТАБЛИЦУ':'SPREADSHEET LINK','ВКЛАДКА ТАБЛИЦЫ':'SHEET TAB','Сначала вставьте ссылку':'Paste a link first','ИСТОЧНИК':'SOURCE','НАБОР ТИТРОВ':'TITLE SET','Без входа в Google. Доступ: «Все, у кого есть ссылка → Читатель».':'No Google sign-in. Access: Anyone with the link → Viewer.','output → файл':'output → file','Загрузить и проверить':'Load and review',
    'Исходная композиция остаётся без изменений':'The source composition remains unchanged','Обновить из AE':'Refresh from AE','Превью композиции появится здесь':'Composition preview will appear here','Обновить превью':'Refresh preview','ИТОГОВАЯ КОМПОЗИЦИЯ':'MASTER COMPOSITION','Откройте и сохраните проект AE':'Open and save an AE project','Перейти к проверке':'Continue to review',
    'Проверка данных':'Data review','↻ Проверить снова':'↻ Check again','все титры':'all titles','новых титров':'new titles','изменено':'changed','ошибки и замечания':'errors and warnings','Нажмите на проблему, чтобы увидеть источник и способ исправления':'Select an issue to see its source and suggested fix','Скачать отчёт':'Download report','Здесь появятся результаты проверки':'Review results will appear here','Перемещение строки не считается изменением.':'Moving a row is not treated as a change.','Убирать табуляцию и переносы из output':'Remove tabs and line breaks from output','Исправляет только имя будущего файла: заменяет Tab и Enter пробелами. Таблицу и текст титров не изменяет.':'Changes only the future filename: replaces Tab and Enter with spaces. The sheet and title text remain unchanged.','Готово к рендеру':'Ready to render','Убрать лишние пробелы…':'Remove extra spaces…','Отменить автоисправление':'Undo automatic fixes',
    'Пакет исправных титров':'Batch of valid titles','не готов':'not ready','готов к сборке':'ready to prepare','ожидает подтверждения':'awaiting approval','ПАПКА ВЫВОДА':'OUTPUT FOLDER','Выберите шаблон':'Choose a template','Выбрать':'Choose','Настроить кодек и альфа в AE ↗':'Configure codec and alpha in AE ↗','Забрать настройки из AE':'Capture settings from AE','Пересоздать все титры':'Rebuild all titles','Контейнер, кодек и альфа берутся из выбранного пресета Output Module.':'Container, codec and alpha come from the selected Output Module preset.','Готовность пакета':'Batch readiness','исправные строки':'valid rows','Имена файлов':'File names','из столбца output':'from the output column','строки будут пропущены':'rows will be skipped','Показать':'Show','ГОТОВО':'READY','Готов к подключению.':'Ready to connect.','Проверьте таблицу перед подготовкой':'Review the sheet before preparing','Открыть очередь AE ↗':'Open AE queue ↗','Остановить':'Stop','Подготовить исправные':'Prepare valid'
    ,'ИТОГОВАЯ КОМПОЗИЦИЯ':'MASTER COMPOSITION','Выберите композицию — T-RUSH найдёт её текстовые слои':'Choose a composition — T-RUSH will find its text layers','Выключить удалённые титры':'Disable missing titles','Демонстрационные данные':'Demo data','Файл:':'File:','неподдерживаемый формат':'unsupported format'
  };
  function language(lang) {
    currentLang = lang; document.documentElement.lang = lang;
    document.querySelectorAll('[data-ru]').forEach(el => { el.textContent = el.dataset[lang] || el.dataset.ru; });
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false); let node;
    while ((node = walker.nextNode())) {
      if (node.parentElement && node.parentElement.closest('[data-ru]')) continue;
      const value = node.nodeValue.trim(); if (!value) continue;
      if (!node._ru) node._ru = value;
      const target = lang === 'en' ? translations[node._ru] : node._ru;
      if (target) node.nodeValue = node.nodeValue.replace(value, target);
    }
    document.querySelectorAll('[data-lang]').forEach(el => el.classList.toggle('active', el.dataset.lang === lang));
    $('status').textContent = t(lastStatus.ru, lastStatus.en);
    $('reviewSubtitle').textContent = $('sheetTab').value || t('Таблица ещё не загружена', 'No sheet loaded yet');
    if (templateSchema) $('templateInfo').textContent = t('Автоматически связано полей: ', 'Automatically mapped fields: ') + templateSchema.fields.length;
    else if (templateDiscovery) $('templateInfo').textContent = templateDiscovery.errors.length ? templateDiscovery.errors.map(issueText).join('\n') : t('Найдено текстовых слоёв: ', 'Text layers found: ') + templateDiscovery.textLayers.length + t(' · композиций с вложениями: ', ' · nested compositions: ') + templateDiscovery.compositions;
    if (checked) { renderReport(); $('renderState').textContent = reviewApproved ? t('готов к сборке', 'ready to prepare') : t('ожидает подтверждения', 'awaiting approval'); }
    syncButtons();
  }
  function persist() {
    savedFields.forEach(id => { saved[id] = $(id).type === 'checkbox' ? $(id).checked : $(id).value; });
    try { if (!demo) localStorage.setItem('titleflow.settings', JSON.stringify(saved)); } catch (_) {}
  }
  function issueCounts() {
    if (!checked) return { errors: 0, warnings: 0, total: 0 };
    const errors = checked.validation.errors.length + checked.hostErrors.length;
    const warnings = checked.validation.warnings.length + checked.hostWarnings.length;
    return { errors, warnings, total: errors + warnings };
  }
  function syncButtons() {
    const ready = selectedRecords().length, issues = issueCounts();
    const counts = titleSelection.counts(), all = $('selectAllTitles');
    const allSelected = counts.eligible > 0 && ready === counts.eligible;
    all.classList.toggle('selected', allSelected);
    all.setAttribute('aria-pressed', allSelected ? 'true' : ready ? 'mixed' : 'false');
    all.textContent = !ready || allSelected ? t('Выбрать все', 'Select all') : t('Выбрано · ', 'Selected · ') + ready;
    all.title = allSelected ? t('Снять выбор со всех титров', 'Clear all selected titles') : t('Выбрать все исправные титры во всех фильтрах', 'Select all valid titles across all filters');
    all.disabled = busy || !checked || !counts.eligible;
    $('selectionCount').textContent = checked ? t('Выбрано ', 'Selected ') + ready + t(' из ', ' of ') + counts.total : '';
    $('countReady').textContent = ready;
    $('autoFixText').disabled = busy || !checked;
    $('undoAutoFix').disabled = busy || !textEdits.canUndo(checked && checked.editScope);
    document.querySelectorAll('.edit-title').forEach(button => { button.disabled = busy || !checked || button.dataset.editable === 'false'; });
    document.querySelectorAll('input[data-title-id]').forEach(input => { input.checked = titleSelection.has(input.dataset.titleId); input.disabled = busy || !checked || !titleSelection.eligible(input.dataset.titleId); });
    $('generate').disabled = busy || !checked || !reviewApproved || checked.blockingErrors.length > 0 || checked.hostErrors.length > 0 || !ready;
    $('generate').textContent = ready ? t('Подготовить выбранные · ', 'Prepare selected · ') + ready : t('Подготовить выбранные', 'Prepare selected');
    $('approveReview').disabled = busy || !checked || !ready || checked.blockingErrors.length > 0 || checked.hostErrors.length > 0;
    $('approveReview').classList.toggle('approved', reviewApproved);
    $('approveReview').setAttribute('aria-pressed', String(reviewApproved));
    $('approveReview').textContent = reviewApproved ? t('Готово к рендеру ✓', 'Ready to render ✓') : t('Готово к рендеру', 'Ready to render');
    $('disableRemoved').hidden = !checked || !checked.diff.some(d => d.type === 'removed');
    $('renderReady').textContent = checked ? ready : '—';
    $('renderSkipped').textContent = checked ? issueCountLabel(issues.errors, issues.warnings) : '—';
    $('renderIssuesText').textContent = checked ? t('ошибок + замечаний', 'errors + warnings') : t('ошибки и замечания', 'errors and warnings');
    const issueRow = $('renderIssuesRow');
    issueRow.classList.toggle('bad', !!checked && issues.errors > 0);
    issueRow.classList.toggle('warning', !!checked && issues.errors === 0 && issues.warnings > 0);
    issueRow.classList.toggle('good', !!checked && issues.total === 0);
    $('renderIssuesIcon').textContent = !checked || issues.total ? '!' : '✓';
    $('renderBadge').textContent = checked && reviewApproved ? ready : '—';
    $('footerSummary').textContent = checked ? ready + t(' титров можно подготовить', ' titles can be prepared') : t('Проверьте таблицу перед подготовкой', 'Review the sheet before preparing');
  }
  function showFailure(error) {
    const message = error && error.message ? error.message : String(error);
    status(message, true, errorEnglish(message));
    if (document.querySelector('#screen-review.active')) {
      if (checked) return;
      const root = $('report'); root.textContent = '';
      const row = textNode('div', '', 'report-row');
      row.appendChild(localizedText(textNode('strong', '', 'report-id'), 'Проверка не выполнена', 'Review failed'));
      row.appendChild(localizedText(textNode('div', '', 'error-message'), message, errorEnglish(message)));
      root.appendChild(row);
    }
  }
  async function run(fn) {
    if (busy) return; busy = true; syncButtons();
    try { await fn(); } catch (e) { showFailure(e); }
    finally { busy = false; syncButtons(); }
  }
  let hostLoadedForPanel = false;
  function host(action, args) {
    if (demo) return window.TitleFlowDemo.host(action, args || {});
    if (!cep) return Promise.reject(new Error('Откройте TitleFlow внутри After Effects. Для просмотра интерфейса используйте ?demo=1.'));
    if (action === 'folder' && window.cep_node && window.cep_node.require('os').platform() === 'win32') {
      const base = decodeURI(cep.getSystemPath('extension')).replace(/^file:\/\//i, '').replace(/^\/(?=[A-Za-z]:[\\/])/, '').replace(/\\/g, '/').replace(/\/$/, '');
      return window.cep_node.require(base + '/js/windows-folder-picker.js').pick({initialFolder:$('outputFolder').value, title:t('Папка для готовых титров', 'Output folder for titles')});
    }
    const encoded = JSON.stringify(JSON.stringify(Object.assign({}, args, { action }))).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
    return new Promise((resolve, reject) => {
      const scriptPath = decodeURI(cep.getSystemPath('extension')).replace(/^file:\/\//i, '').replace(/^\/(?=[A-Za-z]:[\\/])/, '').replace(/\\/g, '/').replace(/\/$/, '') + '/host/main.jsx';
      const script = '(function(){try{if(' + (!hostLoadedForPanel ? 'true' : 'typeof TitleFlow === "undefined"') + ') $.evalFile(' + JSON.stringify(scriptPath) + ');return TitleFlow.dispatch(' + encoded + ');}catch(e){return \"HOST_ERROR: \"+e.toString()+\" (line \"+e.line+\")\";}}())';
      cep.evalScript(script, raw => {
        try { const r = JSON.parse(raw); hostLoadedForPanel = true; if (!r.ok) reject(new Error(r.error)); else resolve(r.value); }
        catch (_) { reject(new Error('Ошибка связи с AE: ' + String(raw).slice(0, 500))); }
      });
    });
  }
  function args() {
    if (!project) throw new Error('Сначала загрузите проект из AE.');
    if (!$('template').value) throw new Error('Выберите итоговую композицию.');
    if (!$('dataset').value.trim()) throw new Error('Укажите постоянное имя набора титров.');
    const layerMap = templateSchema ? templateSchema.layerMap : [];
    return { projectPath: project.projectPath, templateId: Number($('template').value), scope: JSON.stringify([$('dataset').value.trim(), $('template').value, layerMap]), fields: templateSchema ? templateSchema.fields : [], layerMap, outputFolder: $('outputFolder').value, outputTemplate: $('outputTemplate').value, renderTemplate: $('renderTemplate').value };
  }
  function snapshotKey(a) {
    let source;
    if ($('sourceMode').value === 'google') {
      const ref = C.sheetRef($('sheetUrl').value, $('sheetTab').value);
      const option = $('sheetTab').options[$('sheetTab').selectedIndex];
      source = ['google', ref.id, ref.tab, option && option.dataset.gid || ref.gid || ''].join(':');
    } else if ($('sourceMode').value === 'csv') {
      source = csv ? ['csv', csv.name, csv.size, csv.lastModified].join(':') : 'csv';
    } else source = 'demo';
    return JSON.stringify([a.projectPath, source, a.scope, !!$('cleanOutput').checked]);
  }
  function saveSourceSnapshot(key, rows) {
    sourceSnapshot = { key, rows: JSON.parse(JSON.stringify(rows)), savedAt: Date.now() };
    try { if (!demo) localStorage.setItem('titleflow.sourceSnapshot', JSON.stringify(sourceSnapshot)); } catch (_) {}
  }
  function fillSelect(id, entries, selected) {
    const el = $(id); el.textContent = '';
    entries.forEach(item => { const o = document.createElement('option'); o.value = typeof item === 'string' ? item : item.value; o.textContent = typeof item === 'string' ? item : item.label; el.appendChild(o); });
    if (Array.from(el.options).some(o => o.value === String(selected))) el.value = selected;
    if (el._refreshCustom) el._refreshCustom();
  }
  function setupCustomSelect(select) {
    if (select.id === 'filter' || select._customReady) return;
    select._customReady = true;
    const shell = textNode('div', '', 'custom-select'), trigger = textNode('button', '', 'select-trigger'), menu = textNode('div', '', 'select-menu');
    select.parentNode.insertBefore(shell, select); shell.appendChild(select); shell.appendChild(trigger); shell.appendChild(menu);
    function close() { shell.classList.remove('open'); }
    function render() {
      trigger.disabled = select.disabled; trigger.textContent = select.selectedOptions[0] ? select.selectedOptions[0].textContent : t('Выберите', 'Choose');
      menu.textContent = '';
      Array.from(select.options).forEach(option => {
        if (option.hidden) return;
        const item = textNode('button', '', 'select-option');
        item.appendChild(textNode('i', option.value === select.value ? '✓' : ''));
        item.appendChild(textNode('span', option.textContent));
        item.classList.toggle('selected', option.value === select.value); item.disabled = option.disabled;
        item.onclick = event => { event.stopPropagation(); select.value = option.value; render(); close(); select.dispatchEvent(new Event('change', { bubbles: true })); };
        menu.appendChild(item);
      });
    }
    trigger.onclick = event => { event.stopPropagation(); if (select.disabled) return; const opening = !shell.classList.contains('open'); document.querySelectorAll('.custom-select.open').forEach(x => x.classList.remove('open')); if (opening) { const rect = trigger.getBoundingClientRect(), below = window.innerHeight - rect.bottom - 16, above = rect.top - 16, room = Math.max(120, Math.min(420, Math.max(below, above))); shell.classList.toggle('drop-up', above > below && below < 220); menu.style.maxHeight = room + 'px'; } shell.classList.toggle('open', opening); };
    select._refreshCustom = render; render();
  }
  document.addEventListener('click', () => document.querySelectorAll('.custom-select.open').forEach(x => x.classList.remove('open')));
  function invalidate() { reviewApproved = false; checked = null; workflow('review', false); workflow('render', false); $('renderState').textContent = t('не готов', 'not ready'); $('renderState').classList.remove('ready'); localizedText($('summary'), 'Настройки изменились. Проверьте данные заново.', 'Settings changed. Run the review again.'); syncButtons(); persist(); }
  function renderSettingsChanged() {
    if (checked) { checked.settingsChanged = true; checked.args = args(); renderReport(); }
    persist(); syncButtons();
  }
  function sourceUI() { $('googleSource').hidden = $('sourceMode').value !== 'google'; $('csvSource').hidden = $('sourceMode').value !== 'csv'; }
  async function inspectTemplate() {
    const a = args(), result = await host('discover', a), chips = $('templateFields');
    templateDiscovery = result; chips.textContent = '';
    result.textLayers.forEach(item => chips.appendChild(textNode('span', '✓ ' + item.name + (item.count > 1 ? ' ×' + item.count : ''))));
    $('templateInfo').textContent = result.errors.length ? result.errors.map(issueText).join('\n') : t('Найдено текстовых слоёв: ', 'Text layers found: ') + result.textLayers.length + t(' · композиций с вложениями: ', ' · nested compositions: ') + result.compositions;
    $('templateInfo').style.color = result.errors.length ? 'var(--red)' : '';
    workflow('template', !result.errors.length && result.textLayers.length > 0);
    persist(); return result;
  }
  function schemaKey(value) { return String(value == null ? '' : value).trim().toLowerCase().replace(/[\s_.\-]+/g, ''); }
  function buildTemplateSchema(matrix, discovery) {
    const headers = matrix[0].map(value => String(value == null ? '' : value).trim()), byKey = {}, duplicates = {};
    headers.forEach(header => { if (!header || /^(number|output|enabled)$/i.test(header)) return; const key = schemaKey(header); if (byKey[key] && byKey[key] !== header) duplicates[key] = true; else byKey[key] = header; });
    const layerMap = [], fields = [];
    discovery.textLayers.forEach(item => { const key = schemaKey(item.name), field = !duplicates[key] && byKey[key]; if (field) { layerMap.push({ layer: item.name, field }); if (fields.indexOf(field) < 0) fields.push(field); } });
    if (!fields.length) throw new Error(t('Ни один текстовый слой композиции не совпал со столбцами таблицы. Названия можно различать пробелами, подчёркиваниями и регистром.', 'No composition text layer matches a sheet column. Names may differ only by spaces, underscores, hyphens, or letter case.'));
    return { fields, layerMap };
  }
  async function loadRenderPresets() {
    if (!project || !$('template').value) throw new Error('Сначала выберите итоговую композицию во вкладке «Шаблон».');
    const result = await host('presets', args());
    fillSelect('renderTemplate', result.renderTemplates, $('renderTemplate').value || saved.renderTemplate);
    fillSelect('outputTemplate', result.outputTemplates, $('outputTemplate').value || saved.outputTemplate);
    persist();
  }
  async function refresh() {
    checked = null; templateSchema = null; templateDiscovery = null; project = await host('list');
    fillSelect('template', project.comps.map(c => ({ value: c.id, label: c.name })), $('template').value || saved.template);
    $('connection').textContent = demo ? 'Демо · AE 2026' : 'AE ' + project.version;
    $('connection').classList.add('online');
    status(project.comps.length ? 'Проект подключён. Выберите итоговую композицию.' : 'В проекте нет композиций.', false, project.comps.length ? 'Project connected. Choose the master composition.' : 'The project has no compositions.');
  }
  async function loadSheets() {
    const source = $('sheetUrl').value.trim(), match = source.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
    const id = match ? match[1] : source;
    if (!/^[a-zA-Z0-9_-]{20,}$/.test(id)) { $('check').disabled = true; $('sheetTab').disabled = true; fillSelect('sheetTab', [{ value: '', label: 'Вставьте корректную ссылку' }], ''); $('sourceState').textContent = 'нужна ссылка'; $('sourceState').classList.remove('ready'); workflow('source', false); workflow('template', false); return; }
    if (!google) throw new Error('Модуль Google Sheets не загружен.');
    $('sourceState').textContent = t('загрузка…', 'loading…'); status('Получаю список вкладок Google Sheets…', false, 'Loading Google Sheets tabs…');
    const sheets = await google.listPublicSheets(id);
    fillSelect('sheetTab', sheets.map(s => ({ value: s.title, label: s.title })), '');
    Array.from($('sheetTab').options).forEach((option, index) => { option.dataset.gid = sheets[index].gid; });
    $('dataset').value = $('sheetTab').value;
    $('sheetTab').disabled = false; if ($('sheetTab')._refreshCustom) $('sheetTab')._refreshCustom(); $('check').disabled = false; $('sourceState').textContent = t('● доступна', '● available'); $('sourceState').classList.add('ready'); workflow('source', true);
    status('Таблица доступна. Выберите вкладку и шаблон.', false, 'The sheet is available. Choose a tab and template.'); persist();
  }
  function readFile(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = () => reject(new Error('Не удалось прочитать файл. Выберите обновлённый файл заново.')); r.readAsText(file, 'UTF-8');
    });
  }
  async function readRawMatrix() {
    if ($('sourceMode').value === 'demo' && demo) return window.TitleFlowDemo.matrix();
    if ($('sourceMode').value === 'csv') { if (!csv) throw new Error('Выберите CSV / TSV.'); return C.parseCSV(await readFile(csv)); }
    if (!google) throw new Error('Чтение Google Sheets доступно внутри установленной панели AE.');
    const ref = C.sheetRef($('sheetUrl').value, $('sheetTab').value);
    const option = $('sheetTab').options[$('sheetTab').selectedIndex];
    return C.parseCSV(await google.readPublicSheet(ref.id, ref.tab, option && option.dataset.gid || ref.gid));
  }
  function textNode(tag, text, className) { const el = document.createElement(tag); el.textContent = text; if (className) el.className = className; return el; }
  function visible(text) { return text.replace(/\t/g, '⇥'); }
  function issueEnglish(message) {
    let m = String(message);
    Object.values(window.TitleFlowTextEdits.messages).forEach(pair => { m = m.replace(pair[0], pair[1]); });
    m = m.replace('источник изменился после локальной правки. Верните строку из таблицы или сохраните правку заново.', 'source changed after a local edit. Restore the source row or save your edit again.');
    m = m.replace(': лишние пробелы, табуляция или пробел/перенос на краю текста; проверьте вёрстку.', ': contains repeated spaces, a tab or leading/trailing whitespace; check the layout.')
      .replace(/^Пустое поле (.+?) — соответствующий слой будет очищен\.$/, 'Empty $1 field — the corresponding layer will be cleared.')
      .replace(': длинный текст, проверьте вёрстку.', ': long text; check the layout.')
      .replace(': более 2000 символов.', ': contains more than 2000 characters.')
      .replace(/^В начале или конце output есть пробелы\.$/, 'output has leading or trailing spaces.')
      .replace(/^Пустой output\.$/, 'output is empty.')
      .replace(/^Повторяется output из строки (\d+) \(без учёта регистра\)\.$/, 'output duplicates row $1 (case-insensitive).')
      .replace(/^Нет постоянного ID в (\w+)$/, 'Permanent ID is missing in $1.')
      .replace(/^Имя файла очищено от табуляции и переносов: /, 'Filename was cleaned of tabs and line breaks: ')
      .replace(/^В output есть недопустимые символы для имени файла\.$/, 'output contains characters that are invalid in a filename.')
      .replace(/^output заканчивается точкой или пробелом\.$/, 'output ends with a dot or a space.')
      .replace(/^Укажите output без расширения: оно берётся из Output Module\.$/, 'Enter output without an extension; Output Module supplies it.')
      .replace(/^Уберите из output символы шаблона имени файла: /, 'Remove filename-template characters from output: ');
    return errorEnglish(m);
  }
  function errorEnglish(message) {
    return String(message).split('\n').map(line => line
      .replace(/^Вставьте ссылку на Google-таблицу или её ID\.$/, 'Paste a Google Sheets link or its ID.')
      .replace(/^Укажите название вкладки таблицы\.$/, 'Choose a sheet tab.')
      .replace(/^Таблица пуста\.$/, 'The sheet is empty.')
      .replace(/^Повторяется заголовок (.+)$/, 'Duplicate column header: $1')
      .replace(/^Нет столбца (.+)$/, 'Missing column: $1')
      .replace(/^Нет постоянного ID в (.+)$/, 'Permanent ID is missing in $1')
      .replace(/^ID (.+) уже встречается в строке (\d+)$/, 'ID $1 is already used in row $2')
      .replace(/: в ячейке ошибка формулы /, ': the cell contains a formula error ')
      .replace(/^Пустой output\.$/, 'output is empty.')
      .replace(/^В начале или конце output есть пробелы\.$/, 'output has leading or trailing spaces.')
      .replace(/^В output есть недопустимые символы для имени файла\.$/, 'output contains characters that are invalid in a filename.')
      .replace(/^Повторяется output из строки (\d+) \(без учёта регистра\)\.$/, 'output duplicates row $1 (case-insensitive).')
      .replace(/^Не найден текстовый слой (.+)$/, 'Text layer not found: $1')
      .replace(/^(.+): будет обновлено слоёв — (\d+)$/, '$1: $2 layers will be updated')
      .replace(/: слой не текстовый\.$/, ': the target layer is not a text layer.')
      .replace(/: Source Text управляется выражением\.$/, ': Source Text is controlled by an expression.')
      .replace(/: у Source Text есть ключевые кадры\.$/, ': Source Text has keyframes.')
      .replace(/: выражение с comp\(\.\.\.\)\. Нужна адаптация ссылок перед пакетным копированием\.$/, ': an expression uses comp(...); its references must be adapted before batch copying.')
      .replace(/: Essential Properties требуют проверки и адаптации шаблона\.$/, ': Essential Properties require template adaptation.')
      .replace(/^Нет активных записей для обработки\.$/, 'No active records to process.')
      .replace(/^Более 2000 титров: разбейте на несколько листов\.$/, 'More than 2,000 titles: split them across multiple sheets.')
      .replace(/^Сначала загрузите проект из AE\.$/, 'Load the project from AE first.')
      .replace(/^Выберите итоговую композицию\.$/, 'Choose the master composition.')
      .replace(/^Укажите постоянное имя набора титров\.$/, 'Enter a permanent title-set name.')
      .replace(/^Сначала выберите итоговую композицию во вкладке «Шаблон»\.$/, 'Choose the master composition on the Template screen first.')
      .replace(/^Выберите CSV \/ TSV\.$/, 'Choose a CSV / TSV file.')
      .replace(/^Модуль Google Sheets не загружен\.$/, 'The Google Sheets module is not loaded.')
      .replace(/^Чтение Google Sheets доступно внутри установленной панели AE\.$/, 'Google Sheets can be read from the installed AE panel.')
      .replace(/^Исправьте общую ошибку таблицы или шаблона\.$/, 'Fix the sheet or template error.')
      .replace(/^Нет исправных изменений для сборки\.$/, 'There are no valid changes to prepare.')
      .replace(/^Выберите папку вывода\.$/, 'Choose an output folder.')
      .replace(/^Одна из выбранных строк изменилась после проверки\.(.*)$/, 'One of the selected rows changed after review.$1')
      .replace(/^Проект изменился после проверки\.(.*)$/, 'The project changed after review.$1')
      .replace(/^Сначала сохраните проект \.aep\.$/, 'Save the .aep project first.')
      .replace(/^Открыт другой проект\.(.*)$/, 'A different project is open.$1')
      .replace(/^Дождитесь окончания рендера\.$/, 'Wait for rendering to finish.')
      .replace(/^Композиция не найдена\.(.*)$/, 'Composition not found.$1')
      .replace(/^Выберите исходный шаблон, а не созданный титр\.$/, 'Choose the source template, not a generated title.')
      .replace(/^Папка вывода не существует\.$/, 'The output folder does not exist.')
      .replace(/^Недопустимое имя output: /, 'Invalid output name: ')
      .replace(/^Файл уже существует: /, 'File already exists: ')
      .replace(/^Настройки рендера изменились после проверки\.(.*)$/, 'Render settings changed after review.$1')
      .replace(/^Некорректные кавычки в CSV, запись (\d+)$/, 'Invalid CSV quoting in record $1')
      .replace(/^В CSV не закрыта кавычка\.$/, 'An opening quote is not closed in the CSV.')
      .replace(/^output заканчивается точкой или пробелом\.$/, 'output ends with a dot or space.')
      .replace(/^output содержит зарезервированное имя Windows\.$/, 'output contains a reserved Windows name.')
      .replace(/^output длиннее 160 символов\.$/, 'output is longer than 160 characters.')
      .replace(/^output слишком длинный для имени файла в UTF-8\.$/, 'output is too long for a UTF-8 filename.')
      .replace(/^Укажите output без расширения: оно берётся из Output Module\.$/, 'Enter output without an extension; Output Module supplies it.')
      .replace(/^Уберите из output символы шаблона имени файла: /, 'Remove filename-template characters from output: ')
      .replace(/^ID длиннее 80 символов\.$/, 'ID is longer than 80 characters.')
      .replace(/^Google Sheets вернул ошибку (\d+)\.(.*)$/, 'Google Sheets returned error $1.$2')
      .replace(/^Google не отвечает\.(.*)$/, 'Google is not responding.$1')
      .replace(/^Не удалось получить список вкладок\.(.*)$/, 'Could not load the sheet-tab list.$1')
    ).join('\n');
  }
  function issueText(message) { return currentLang === 'en' ? issueEnglish(message) : message; }
  function markedValue(value) {
    const source = String(value == null ? '' : value);
    const code = textNode('code', '');
    if (!source) { code.textContent = t('〈пусто〉', '〈empty〉'); return code; }
    const pattern = /\t|\n|\u00a0| {2,}|^ | $/g;
    let match, offset = 0;
    while ((match = pattern.exec(source))) {
      code.appendChild(document.createTextNode(source.slice(offset, match.index)));
      const token = match[0];
      let label;
      if (token === '\t') label = '⇥ TAB';
      else if (token === '\n') label = '↵ ENTER';
      else if (token === '\u00a0') label = t('NBSP · неразрывный пробел', 'NBSP · non-breaking space');
      else {
        const internal = match.index > 0 && match.index + token.length < source.length;
        const extra = token.length - (internal ? 1 : 0);
        label = '·'.repeat(Math.min(token.length, 12)) + ' [' + token.length + t(' пробелов; лишних: ', ' spaces; extra: ') + extra + ']';
      }
      code.appendChild(textNode('mark', label, 'whitespace-mark'));
      offset = pattern.lastIndex;
    }
    code.appendChild(document.createTextNode(source.slice(offset)));
    return code;
  }
  function markedCell(cell, value) {
    const code = markedValue(value);
    code.insertBefore(document.createTextNode(cell + ': '), code.firstChild);
    return code;
  }
  function columnLetter(index) {
    let n = Number(index) + 1, result = '';
    while (n > 0) { n--; result = String.fromCharCode(65 + n % 26) + result; n = Math.floor(n / 26); }
    return result;
  }
  function issueField(message) { const match = /^([^:]+)\s*:/.exec(message), candidate = match && match[1].trim(); if (candidate === 'output' || (checked && checked.fields.indexOf(candidate) >= 0)) return candidate; return /output|Имя файла|Filename/i.test(message) ? 'output' : ''; }
  function issueSummary(items) {
    const errorFields = [], warningFields = [];
    items.forEach(x => { const field = issueField(x.message) || t('данные строки', 'row data'), target = x.severity === 'error' ? errorFields : warningFields; if (target.indexOf(field) < 0) target.push(field); });
    if (errorFields.length && warningFields.length) return t('Ошибка: ', 'Error: ') + errorFields.join(', ') + t(' · замечание: ', ' · warning: ') + warningFields.join(', ');
    if (errorFields.length) return t('Ошибка в ', 'Error in ') + errorFields.join(', ');
    const hasWhitespace = items.some(x => /табуляц|пробел\/перенос|leading|trailing|tab/i.test(x.message));
    if (hasWhitespace) return t('Лишние пробелы, Tab или Enter в ', 'Extra spaces, Tab or Enter in ') + warningFields.join(', ');
    if (items.some(x => /Пустое поле|Empty .* field/i.test(x.message))) return t('Пустое поле в ', 'Empty field in ') + warningFields.join(', ');
    if (items.some(x => /длинный текст|long text/i.test(x.message))) return t('Длинный текст — проверьте вёрстку', 'Long text — check the layout');
    return issueText(items[0].message);
  }
  function issueSteps(message, field) {
    const steps = [];
    if (/табуляц|пробел\/перенос|leading|trailing|tab/i.test(message)) {
      steps.push(t('Оставьте между словами один обычный пробел.', 'Keep one regular space between words.'));
      steps.push(t('Удалите Tab, лишний пробел или Enter в начале и конце ячейки.', 'Remove tabs, extra spaces or line breaks at the start and end of the cell.'));
    } else if (/Пустое поле|Empty .* field/i.test(message)) steps.push(t('Заполните ячейку, если этот слой должен содержать текст.', 'Fill the cell if this layer should contain text.'));
    else if (/длинный текст|long text/i.test(message)) steps.push(t('Откройте композицию и проверьте, помещается ли текст в макет.', 'Open the composition and verify that the text fits the layout.'));
    else if (field === 'output' || /output|Имя файла|Filename/i.test(message)) steps.push(t('Исправьте исходное поле, из которого формируется имя файла.', 'Fix the source field used to build the filename.'));
    else steps.push(t('Исправьте указанную ячейку.', 'Fix the indicated cell.'));
    return steps;
  }
  function collectIssueGroups(r) {
    const groups = {};
    function add(item, severity) { const key = String(item.row), group = groups[key] || (groups[key] = { row: item.row, items: [] }); group.items.push({ message: item.message, severity }); }
    r.validation.errors.forEach(item => add(item, 'error'));
    r.validation.warnings.forEach(item => add(item, 'warning'));
    r.hostErrors.forEach(message => add({ row: 'AE', message }, 'error'));
    r.hostWarnings.forEach(message => add({ row: 'AE', message }, 'warning'));
    return groups;
  }
  function createIssueCard(group, r) {
    const record = group.row === 'AE' ? null : r.validation.rows.find(x => x.row === Number(group.row));
    const raw = record && r.rawByRow[String(record.row)] || {}, hasError = group.items.some(x => x.severity === 'error');
    const card = textNode('div', '', 'issue-card ' + (hasError ? 'issue-error' : 'issue-warning'));
    const top = textNode('div', '', 'issue-header');
    const issueId = textNode('span', '', 'issue-id');
    if (record) issueId.appendChild(titleCheckbox(record));
    issueId.appendChild(textNode('span', record ? record.id : 'AE')); top.appendChild(issueId);
    const person = textNode('span', '', 'issue-name');
    const primaryField = r.fields && r.fields[0];
    person.appendChild(textNode('b', record ? (record.data[primaryField] || ('ID ' + record.id)) : t('Шаблон After Effects', 'After Effects template')));
    person.appendChild(textNode('small', record ? t('строка таблицы ', 'sheet row ') + record.row : t('проверка композиции', 'composition review')));
    top.appendChild(person);
    if (record) person.appendChild(editButton(record));
    top.appendChild(textNode('span', issueSummary(group.items), 'issue-summary'));
    const toggle = textNode('button', t('раскрыть ↓', 'expand ↓'), 'issue-expand'); top.appendChild(toggle); card.appendChild(top);
    const details = textNode('div', '', 'issue-expanded'); details.hidden = true;
    const left = textNode('section', '', 'issue-source'); left.appendChild(textNode('h3', t('Где появилась ошибка', 'Where the issue appeared')));
    const right = textNode('section', '', 'issue-remedy'); right.appendChild(textNode('h3', t('Что исправить', 'How to fix it')));
    const fields = [], steps = [];
    group.items.forEach(item => {
      const field = issueField(item.message); if (field && fields.indexOf(field) < 0) fields.push(field);
      left.appendChild(textNode('p', issueText(item.message), item.severity === 'error' ? 'error-message' : 'warning-message'));
      issueSteps(item.message, field).forEach(step => { if (steps.indexOf(step) < 0) steps.push(step); });
    });
    const sourceFields = fields.filter(field => field !== 'output'), fixFields = sourceFields.length ? sourceFields : fields;
    if (record && fields.length) {
      const code = textNode('div', '', 'issue-code'), fileHeader = r.fileHeader, outputCol = r.columns.output;
      sourceFields.forEach(field => { const col = r.columns[field], cell = col !== undefined ? columnLetter(col) + record.row : field; code.appendChild(markedCell(cell, record.data[field])); });
      if (fileHeader && raw[fileHeader] !== undefined) code.appendChild(markedCell(columnLetter(r.headerIndexes[fileHeader]) + record.row, raw[fileHeader]));
      if (outputCol !== undefined) code.appendChild(markedCell(columnLetter(outputCol) + record.row, record.data.output));
      left.appendChild(code);
    }
    steps.forEach((step, index) => { const line = textNode('div', '', 'fix-step'); line.appendChild(textNode('i', String(index + 1))); line.appendChild(textNode('span', step)); right.appendChild(line); });
    if (record && fixFields.length) {
      const cells = fixFields.map(field => r.columns[field] !== undefined ? columnLetter(r.columns[field]) + record.row : field).join(', ');
      right.appendChild(textNode('p', t('Исправьте ', 'Fix ') + cells + t(' и снова запустите проверку. Формулы имени файла и output пересчитаются сами.', ' and run the review again. The filename and output formulas will recalculate automatically.'), 'fix-note'));
    }
    details.appendChild(left); details.appendChild(right); card.appendChild(details);
    toggle.onclick = () => { details.hidden = !details.hidden; toggle.textContent = details.hidden ? t('раскрыть ↓', 'expand ↓') : t('свернуть ↑', 'collapse ↑'); };
    return card;
  }
  function renderReport() {
    delete $('summary').dataset.ru; delete $('summary').dataset.en;
    const root = $('report'); root.textContent = ''; if (!checked) return;
    $('reviewSubtitle').textContent = $('sheetTab').value || $('dataset').value;
    const r = checked, filter = $('filter').value, issues = issueCounts(), groups = collectIssueGroups(r);
    document.querySelectorAll('[data-filter]').forEach(el => el.classList.toggle('active', el.dataset.filter === filter));
    ['added', 'changed', 'same'].forEach(type => { $('count' + type[0].toUpperCase() + type.slice(1)).textContent = r.diff.filter(d => d.type === type).length; });
    $('countReady').textContent = selectedRecords().length; $('countAll').textContent = r.validation.rows.length;
    $('countErrors').textContent = issueCountLabel(issues.errors, issues.warnings);
    if (filter === 'issues') Object.keys(groups).sort((a,b) => a === 'AE' ? -1 : b === 'AE' ? 1 : Number(a)-Number(b)).forEach(key => root.appendChild(createIssueCard(groups[key], r)));
    else r.diff.filter(d => {
      if (filter === 'ready') return d.type !== 'removed' && r.validRows[d.record.row] && titleSelection.has(d.record.id);
      if (filter === 'added') return d.type === 'added'; if (filter === 'changed') return d.type === 'changed'; return filter === 'all' && d.type !== 'removed';
    }).forEach(d => {
      const row = textNode('div', '', 'report-row title-row'), top = textNode('div', '', 'report-top'), id = textNode('div', 'ID ' + d.record.id, 'report-id');
      id.appendChild(textNode('span', t('строка ', 'row ') + d.record.row, 'row-number'));
      row.appendChild(titleCheckbox(d.record)); top.appendChild(id);
      const tags = textNode('div', '', 'row-tags'), labels = { added: t('НОВЫЙ', 'NEW'), changed: t('ИЗМЕНЁН', 'CHANGED'), same: t('БЕЗ ИЗМЕНЕНИЙ', 'UNCHANGED'), removed: t('НЕТ В ИСТОЧНИКЕ', 'MISSING FROM SOURCE') };
      tags.appendChild(textNode('span', labels[d.type], 'tag ' + d.type));
      if (textEdits.has(r.editScope, d.record.id)) tags.appendChild(textNode('span', t('ПРАВКА В ПЛАГИНЕ', 'LOCAL EDIT'), 'tag changed'));
      tags.appendChild(editButton(d.record));
      const issueGroup = groups[String(d.record.row)];
      if (issueGroup) { const issueIsError = issueGroup.items.some(x => x.severity === 'error'), issueTag = textNode('button', issueIsError ? t('ОШИБКА', 'ERROR') : t('ЗАМЕЧАНИЕ', 'WARNING'), 'tag issue-link ' + (issueIsError ? 'error' : 'changed')); issueTag.onclick = () => { $('filter').value = 'issues'; document.querySelectorAll('[data-filter]').forEach(x => x.classList.toggle('active', x.dataset.filter === 'issues')); renderReport(); }; tags.appendChild(issueTag); }
      if (filter === 'ready') tags.appendChild(textNode('span', t('ГОТОВ', 'READY'), 'tag added')); top.appendChild(tags); row.appendChild(top);
      row.appendChild(textNode('div', visible(d.record.data[r.fields[0]] || ('ID ' + d.record.id)), 'person'));
      d.changes.forEach(change => { const div = textNode('div', '', 'change'), values = textNode('div', ''); div.appendChild(textNode('span', change.field, 'change-label')); values.appendChild(textNode('div', visible(change.before || t('〈пусто〉', '〈empty〉')), 'before')); values.appendChild(textNode('div', visible(change.after || t('〈пусто〉', '〈empty〉')), 'after')); div.appendChild(values); row.appendChild(div); });
      if (d.type === 'added') row.appendChild(textNode('div', visible(d.record.data.output), 'person')); root.appendChild(row);
    });
    if (!root.children.length) root.appendChild(textNode('div', filter === 'issues' ? t('Ошибок и замечаний нет.', 'No errors or warnings.') : t('Здесь пока ничего нет.', 'Nothing here yet.'), 'empty'));
    const removed = r.diff.filter(d => d.type === 'removed').length;
    $('summary').textContent = r.validation.rows.length + t(' титров · ', ' titles · ') + Object.keys(r.validRows).length + t(' исправных · ', ' valid · ') + r.invalidCount + (currentLang === 'en' ? ' rows with errors · ' : ' ' + pluralRu(r.invalidCount, 'строка', 'строки', 'строк') + ' с ошибками · ') + r.validation.skipped + t(' пустых заготовок пропущено · ', ' empty placeholder rows skipped · ') + removed + t(' отсутствуют в источнике. ', ' missing from the source. ') + (r.comparedWithSnapshot ? t('Сравнение с предыдущей проверкой.', 'Compared with the previous review.') : t('Сравнение с последней сборкой в .aep.', 'Compared with the latest build in the .aep project.'));
    syncButtons();
  }
  function editButton(record) {
    const button = textNode('button', t('Редактировать', 'Edit'), 'edit-title');
    button.dataset.editable = String(!!record.id && checked.validation.rows.filter(row => row.id === record.id).length === 1);
    button.disabled = busy || button.dataset.editable === 'false';
    button.onclick = () => openTitleEditor(record);
    return button;
  }
  let closeTextDialog = null;
  function textDialog(title, note) {
    const overlay = textNode('div', '', 'text-dialog-overlay'), panel = textNode('section', '', 'text-dialog');
    panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-modal', 'true');
    const heading = textNode('h2', title); heading.id = 'textDialogTitle'; panel.setAttribute('aria-labelledby', heading.id);
    panel.appendChild(heading); panel.appendChild(textNode('p', note, 'hint'));
    const body = textNode('div', '', 'text-dialog-body'), actions = textNode('div', '', 'text-dialog-actions');
    const previousFocus = document.activeElement;
    function close() { overlay.remove(); document.removeEventListener('keydown', escape); closeTextDialog = null; if (previousFocus && previousFocus.isConnected) previousFocus.focus(); }
    function escape(event) {
      if (event.key === 'Escape') { event.preventDefault(); close(); }
      if (event.key === 'Tab') {
        const items = Array.from(panel.querySelectorAll('button:not(:disabled),textarea')), first = items[0], last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    }
    const cancel = textNode('button', t('Отмена', 'Cancel')); cancel.onclick = close; actions.appendChild(cancel);
    panel.appendChild(body); panel.appendChild(actions); overlay.appendChild(panel); document.body.appendChild(overlay); document.addEventListener('keydown', escape); closeTextDialog = close;
    cancel.focus(); return {body,actions,close};
  }
  function openTitleEditor(record) {
    if (!checked || busy || closeTextDialog) return;
    const plan = checked, headers = plan.sourceMatrix[0].map(value => String(value).trim()), fields = plan.fields.filter(field => field !== 'output');
    const conflict = plan.editConflicts.some(item => item.id === record.id);
    const dialog = textDialog(t('Редактировать титр · ', 'Edit title · ') + record.id,
      conflict ? t('Источник изменился. Сохранение подтвердит вашу версию поверх текущего текста только в плагине.', 'The source changed. Saving explicitly applies your version locally over the current source text.') : t('Правки сохраняются только в плагине. Переносы строк сохраняются. Имя файла output берётся из таблицы и здесь не изменяется.', 'Edits are local to the plugin. Line breaks are preserved. The output filename comes from the sheet and is not changed here.'));
    const inputs = [];
    fields.forEach(field => {
      const col = headers.indexOf(field); if (col < 0) return;
      const label = textNode('label', field), input = document.createElement('textarea'); input.rows = field === 'output' ? 2 : 3;
      const patch = textEdits.get(plan.editScope, record.id, field);
      input.value = patch ? patch.value : String(plan.sourceMatrix[record.row-1][col] || ''); input.dataset.editField = field;
      label.appendChild(input); dialog.body.appendChild(label); inputs.push({field,col,input});
    });
    const restore = textNode('button', t('Вернуть из таблицы', 'Restore source')); restore.disabled = !textEdits.has(plan.editScope, record.id);
    restore.onclick = () => { textEdits.reset(plan.editScope, record.id); persistTextEdits(); dialog.close(); run(check); }; dialog.actions.appendChild(restore);
    const save = textNode('button', t('Сохранить и проверить', 'Save and review'), 'primary');
    save.onclick = () => {
      inputs.forEach(({field,col,input}) => textEdits.set(plan.editScope, record.id, field, plan.sourceMatrix[record.row-1][col], input.value));
      persistTextEdits(); dialog.close(); run(check);
    }; dialog.actions.appendChild(save); if (inputs.length) inputs[0].input.focus();
  }
  function previewAutoFix() {
    if (!checked || busy || closeTextDialog) return;
    if (checked.editConflicts.length) { status('Сначала разрешите конфликты локальных правок.', true, 'Resolve local edit conflicts first.'); return; }
    const scope = checked.editScope;
    const changes = textEdits.plan(checked.sourceMatrix, scope, checked.fields).filter(change => checked.validation.rows.some(record => record.id === change.id && record.row === change.row));
    const dialog = textDialog(t('Автоисправление · ', 'Automatic cleanup · ') + changes.length + ' ' + t(pluralRu(changes.length, 'поле', 'поля', 'полей'), changes.length === 1 ? 'field' : 'fields'), t('Во всех титрах: заменяем Tab и повторяющиеся обычные пробелы одним пробелом, убираем их по краям строк. Переносы строк и неразрывные пробелы сохраняются. Таблица и имена файлов не меняются. Точки обозначают пробелы, ⇥ — Tab.', 'Across all titles: replace tabs and repeated regular spaces with one space and remove them at line edges. Line breaks and non-breaking spaces are preserved. The sheet and filenames stay unchanged. Dots indicate spaces; ⇥ indicates a tab.'));
    const show = value => value.replace(/ /g, '·').replace(/\t/g, '⇥').replace(/\n/g, '↵\n');
    changes.forEach(change => {
      const card = textNode('section', '', 'text-fix-preview'); card.appendChild(textNode('b', 'ID ' + change.id + ' · ' + change.field));
      card.appendChild(textNode('small', t('Было', 'Before'))); card.appendChild(textNode('pre', show(change.before), 'before'));
      card.appendChild(textNode('small', t('Станет', 'After'))); card.appendChild(textNode('pre', show(change.after), 'after')); dialog.body.appendChild(card);
    });
    if (!changes.length) dialog.body.appendChild(textNode('p', t('Лишних пробелов и Tab не найдено.', 'No extra spaces or tabs found.')));
    const apply = textNode('button', t('Применить · ', 'Apply · ') + changes.length, 'primary'); apply.disabled = !changes.length;
    apply.onclick = () => { textEdits.auto(scope, changes); persistTextEdits(); dialog.close(); run(check); }; dialog.actions.appendChild(apply);
  }
  function titleCheckbox(record) {
    const label = textNode('label', '', 'title-checkbox');
    const input = document.createElement('input'); input.type = 'checkbox';
    input.dataset.titleId = String(record.id); input.checked = titleSelection.has(record.id);
    input.disabled = busy || !titleSelection.eligible(record.id);
    input.setAttribute('aria-label', t('Выбрать титр ', 'Select title ') + record.id);
    label.title = titleSelection.eligible(record.id) ? t('Выбрать для подготовки', 'Select for preparation') : t('Строку с ошибкой выбрать нельзя', 'Rows with errors cannot be selected');
    input.onchange = () => { titleSelection.set(record.id, input.checked); selectionChanged(); };
    label.appendChild(input); return label;
  }
  function selectionChanged() {
    if (reviewApproved) { reviewApproved = false; }
    const issues = issueCounts();
    workflow('review', issues.total > 0, issues.total ? issues.errors + ' + ' + issues.warnings : '—');
    workflow('render', false);
    $('renderState').textContent = t('ожидает подтверждения', 'awaiting approval');
    $('renderState').classList.remove('ready');
    status('Выбор изменён. Подтвердите готовность к рендеру.', false, 'Selection changed. Confirm readiness to render.');
    syncButtons();
  }
  function selectedRecords() {
    return checked ? titleSelection.records() : [];
  }
  function validationOptions(fields) {
    let windows = false;
    try { windows = !!window.cep_node && window.cep_node.require('os').platform() === 'win32'; } catch (_) {}
    return {cleanOutput:$('cleanOutput').checked, fields, safeOutput:windows};
  }
  function sameRecord(a, b, fields) {
    return !!a && !!b && a.id === b.id && fields.concat(['output']).every(field => a.data[field] === b.data[field]);
  }
  async function check() {
    screen('review');
    checked = null; status('Читаю данные и проверяю шаблон…', false, 'Reading data and checking the template…');
    const sourceMatrix = await readRawMatrix(), discovery = await inspectTemplate();
    templateSchema = buildTemplateSchema(sourceMatrix, discovery);
    const a = args(), inspection = await host('inspect', a);
    const editScope = snapshotKey(a), editResult = textEdits.apply(sourceMatrix, editScope, templateSchema.fields.filter(field => field !== 'output')), matrix = editResult.matrix;
    const validation = C.validate(matrix, validationOptions(templateSchema.fields));
    validation.rows.forEach(record => templateSchema.fields.forEach(field => {
      textEdits.issues(record.data[field]).forEach(issue => validation.warnings.push({row:record.row,message:field + ': ' + issue.ru}));
    }));
    editResult.conflicts.forEach(conflict => validation.errors.push({row:conflict.row,message:conflict.field + ': источник изменился после локальной правки. Верните строку из таблицы или сохраните правку заново.'}));
    const baseline = await host('baseline', Object.assign({}, a, { includeSettings: false }));
    const currentSnapshotKey = snapshotKey(a);
    const comparedWithSnapshot = !!(sourceSnapshot && sourceSnapshot.key === currentSnapshotKey);
    const comparisonRows = comparedWithSnapshot ? sourceSnapshot.rows : baseline.items.map(item => item.record);
    const badRows = {}, blockingErrors = validation.errors.filter(error => error.row === 1);
    validation.errors.forEach(error => { if (error.row !== 1) badRows[error.row] = true; });
    const validRows = {};
    validation.rows.forEach(row => { if (!badRows[row.row]) validRows[row.row] = true; });
    const headers = matrix[0].map(value => String(value == null ? '' : value).trim()), headerIndexes = {}, columns = {}, rawByRow = {};
    headers.forEach((header, index) => { if (header) headerIndexes[header] = index; });
    templateSchema.fields.concat(['output']).forEach(field => { if (headerIndexes[field] !== undefined) columns[field] = headerIndexes[field]; });
    validation.rows.forEach(record => { const values = matrix[record.row - 1] || [], raw = {}; headers.forEach((header, index) => { if (header) raw[header] = String(values[index] == null ? '' : values[index]); }); rawByRow[String(record.row)] = raw; });
    const fileHeader = headers.find(header => /имя файла|file.?name/i.test(header)) || '';
    checked = { sourceMatrix, editScope, editConflicts: editResult.conflicts, validation, baseline, args: a, fields: templateSchema.fields.slice(), layerMap: templateSchema.layerMap.slice(), hostErrors: inspection.errors, hostWarnings: inspection.warnings, blockingErrors, validRows, invalidCount: Object.keys(badRows).length, buildDiff: C.diff(validation.rows, baseline.items.map(item => item.record), templateSchema.fields), diff: C.diff(validation.rows, comparisonRows, templateSchema.fields), comparedWithSnapshot, settingsChanged: false, rawByRow, columns, headerIndexes, fileHeader };
    titleSelection.reconcile(validation.rows, validRows, currentSnapshotKey);
    const chips = $('templateFields'); chips.textContent = ''; templateSchema.layerMap.forEach(item => chips.appendChild(textNode('span', '✓ ' + item.field + ' → ' + item.layer)));
    $('templateInfo').textContent = t('Автоматически связано полей: ', 'Automatically mapped fields: ') + templateSchema.fields.length;
    saveSourceSnapshot(currentSnapshotKey, validation.rows);
    reviewApproved = false;
    const issues = issueCounts();
    $('filter').value = issues.total ? 'issues' : 'all';
    renderReport(); persist();
    workflow('review', issues.total > 0, issues.total ? (issues.errors + ' + ' + issues.warnings) : '—');
    workflow('render', false);
    $('renderState').textContent = t('ожидает подтверждения', 'awaiting approval'); $('renderState').classList.remove('ready'); screen('review');
    const ready = selectedRecords().length;
    status((validation.errors.length ? 'Есть строки с ошибками. ' : '') + 'Можно подготовить исправных: ' + ready + '. Исходная композиция останется без изменений.', !!(blockingErrors.length || inspection.errors.length), (validation.errors.length ? 'Some rows contain errors. ' : '') + 'Valid titles ready: ' + ready + '. The source composition will remain unchanged.');
  }
  function approveReview() {
    if (!checked || !selectedRecords().length || checked.blockingErrors.length || checked.hostErrors.length) return;
    reviewApproved = !reviewApproved;
    if (!reviewApproved) {
      const issues = issueCounts();
      workflow('review', issues.total > 0, issues.total ? issues.errors + ' + ' + issues.warnings : '—');
      workflow('render', false);
      $('renderState').textContent = t('ожидает подтверждения', 'awaiting approval');
      $('renderState').classList.remove('ready');
      status('Подтверждение снято. Подготовка заблокирована.', false, 'Approval cleared. Preparation is disabled.');
      syncButtons(); return;
    }
    workflow('review', true, '✓');
    workflow('render', true, String(selectedRecords().length));
    $('renderState').textContent = t('готов к сборке', 'ready to prepare'); $('renderState').classList.add('ready');
    status('Проверка подтверждена. Можно переходить к рендеру.', false, 'Review approved. You can continue to render.');
    syncButtons();
  }
  async function generate() {
    if (!checked || !reviewApproved || checked.blockingErrors.length || checked.hostErrors.length) throw new Error(t('Подтвердите проверку выбранных титров.', 'Approve the selected titles first.'));
    screen('render');
    if (!$('renderTemplate').value || !$('outputTemplate').value) await loadRenderPresets();
    if (!$('renderTemplate').value || !$('outputTemplate').value) throw new Error(t('Выберите Render Settings и Output Module во вкладке Рендер.', 'Choose Render Settings and Output Module on the Render screen.'));
    const plan = checked, rows = selectedRecords(); if (!rows.length) throw new Error('Нет исправных изменений для сборки.');
    const currentEdits = textEdits.apply(await readRawMatrix(), plan.editScope, plan.fields.filter(field => field !== 'output'));
    if (currentEdits.conflicts.some(conflict => rows.some(record => record.id === conflict.id))) { await check(); throw new Error(t('Источник изменился. Разрешите конфликт локальных правок.', 'The source changed. Resolve local edit conflicts.')); }
    const currentValidation = C.validate(currentEdits.matrix, validationOptions(plan.fields));
    const currentErrors = {}, currentById = {};
    currentValidation.errors.forEach(error => { currentErrors[error.row] = true; });
    currentValidation.rows.forEach(record => { if (!currentErrors[record.row]) currentById[record.id] = record; });
    if (rows.some(record => !sameRecord(record, currentById[record.id], plan.fields))) { await check(); throw new Error('Одна из выбранных строк изменилась после проверки. Отчёт обновлён — нажмите подготовку ещё раз.'); }
    if (!args().outputFolder) throw new Error('Выберите папку вывода.');
    const liveBaseline = await host('baseline', args());
    if (liveBaseline.signature !== plan.baseline.signature) { await check(); throw new Error('Проект изменился после проверки. Отчёт обновлён — нажмите подготовку ещё раз.'); }
    let begun = false, done = 0; cancelled = false;
    try {
      await host('begin', Object.assign({}, args(), { rows, baselineSignature: liveBaseline.signature, settingsSignature: liveBaseline.settings })); begun = true;
      $('cancel').hidden = false; $('progress').hidden = false; $('progress').max = rows.length; $('progress').value = 0;
      while (done < rows.length && !cancelled) {
        const result = await host('next'); done = result.done; $('progress').value = done;
        status('Подготовлено ' + done + ' из ' + rows.length + ' · ID ' + result.id, false, 'Prepared ' + done + ' of ' + rows.length + ' · ID ' + result.id);
        await new Promise(resolve => setTimeout(resolve, 0));
      }
      status((cancelled ? 'Подготовка остановлена. ' : 'Очередь подготовлена. ') + 'Создано ' + done + ' из ' + rows.length + '. Сохраните .aep и проверьте титры перед Render.', false, (cancelled ? 'Preparation stopped. ' : 'Queue prepared. ') + 'Created ' + done + ' of ' + rows.length + '. Save the .aep and review the titles before rendering.');
    } catch (e) { throw new Error('Создано ' + done + ' из ' + rows.length + '. ' + e.message + (done ? ' Уже готовые титры сохранены в открытом проекте.' : '')); }
    finally {
      if (begun) {
        await host('end');
        if (done > 0) { await check(); screen('render'); }
        else if (checked) { renderReport(); }
      }
      $('cancel').hidden = true; $('progress').hidden = true;
    }
  }

  $('refresh').onclick = () => run(async () => { await refresh(); if (project && project.comps.length) await inspectTemplate(); });
  $('check').onclick = () => run(check);
  $('generate').onclick = () => run(generate);
  $('approveReview').onclick = approveReview;
  $('cancel').onclick = () => { cancelled = true; status('Остановлю после текущего титра…', false, 'Stopping after the current title…'); };
  $('filter').onchange = renderReport;
  document.querySelectorAll('.nav').forEach(el => { el.onclick = () => { if (el.dataset.screen === 'review' && checked) { $('filter').value = 'all'; renderReport(); } screen(el.dataset.screen); if (el.dataset.screen === 'render' && project && $('template').value && $('renderTemplate').options.length <= 1) run(loadRenderPresets); }; });
  document.querySelectorAll('[data-filter]').forEach(el => { el.onclick = () => { $('filter').value = el.dataset.filter; document.querySelectorAll('[data-filter]').forEach(x => x.classList.remove('active')); el.classList.add('active'); renderReport(); }; });
  document.querySelectorAll('[data-lang]').forEach(el => { el.onclick = () => language(el.dataset.lang); });
  if ($('checkAgain')) $('checkAgain').onclick = () => run(check);
  if ($('goReview')) $('goReview').onclick = () => run(check);
  if ($('showProblems')) $('showProblems').onclick = () => { $('filter').value = checked && issueCounts().total ? 'issues' : 'all'; renderReport(); screen('review'); };
  if ($('replaySplash')) $('replaySplash').onclick = () => { const splash = $('splash'); splash.style.animation = 'none'; void splash.offsetWidth; splash.style.animation = ''; };
  $('autoFixText').onclick = previewAutoFix;
  $('undoAutoFix').onclick = () => { textEdits.undo(checked && checked.editScope); persistTextEdits(); run(check); };
  $('sourceMode').onchange = () => { sourceUI(); invalidate(); };
  let sheetTimer;
  $('sheetUrl').oninput = () => { clearTimeout(sheetTimer); $('check').disabled = true; invalidate(); sheetTimer = setTimeout(() => run(loadSheets), 500); };
  $('sheetTab').onchange = () => { $('dataset').value = $('sheetTab').value; invalidate(); };
  ['dataset', 'cleanOutput'].forEach(id => { $(id).onchange = invalidate; });
  $('selectAllTitles').onclick = () => { const counts = titleSelection.counts(); titleSelection.setAll(counts.selected !== counts.eligible); selectionChanged(); };
  $('rebuildAll').onchange = () => { titleSelection.setAll(true); selectionChanged(); };
  $('template').onchange = () => { templateSchema = null; templateDiscovery = null; invalidate(); run(inspectTemplate); };
  ['outputTemplate', 'renderTemplate'].forEach(id => { $(id).onchange = () => { renderSettingsChanged(); run(async () => { const p = await host('presets', args()); $('presetSummary').textContent = ['Файл: ' + (p.extension || 'неподдерживаемый формат'), p.outputSettings.Format, p.outputSettings.Channels, p.outputSettings.Depth].filter(Boolean).join(' · '); }); }; });
  $('browse').onclick = () => run(async () => { const path = await host('folder'); if (path) { $('outputFolder').value = path; renderSettingsChanged(); } });
  $('csvFile').onchange = () => { csv = $('csvFile').files[0]; invalidate(); };
  $('showQueue').onclick = () => run(async () => { await host('showQueue', args()); });
  $('disableRemoved').onclick = () => run(async () => { if (!checked) return; const ids = checked.diff.filter(d => d.type === 'removed').map(d => d.record.id); const r = await host('disableRemoved', Object.assign({}, args(), { ids })); status('Выключено заданий: ' + r.disabled + '. Композиции сохранены.', false, 'Disabled jobs: ' + r.disabled + '. Compositions were kept.'); });
  document.querySelectorAll('a[href="https://t.me/cgeventprod"]').forEach(link => {
    link.addEventListener('click', event => {
      if (!cep) return;
      event.preventDefault();
      try {
        const result = window.cep.util.openURLInDefaultBrowser('https://t.me/cgeventprod');
        if (result && result.err) throw new Error('Browser error: ' + result.err);
      } catch (error) {
        status('Не удалось открыть ссылку: https://t.me/cgeventprod', true, 'Could not open the link: https://t.me/cgeventprod');
      }
    });
  });
  document.querySelectorAll('select').forEach(setupCustomSelect);
  sourceUI();
  workflow('source', false); workflow('template', false); workflow('review', false); workflow('render', false);
  if (cep && !demo) {
    try {
      let base = cep.getSystemPath('extension').replace(/^file:\/\//, ''); base = decodeURI(base); if (/^\/[A-Za-z]:/.test(base)) base = base.slice(1);
      google = window.cep_node.require(base + '/js/google.js').createClient();
    } catch (e) { status('Google-модуль не загрузился: ' + e.message + '. CSV остаётся доступен.', true, 'Google module failed to load: ' + errorEnglish(e.message) + '. CSV remains available.'); }
  }
  if (cep || demo) run(async () => { await refresh(); if (demo) { $('outputFolder').value = '/renders/titles/v01'; await check(); } });
  else { $('connection').textContent = t('AE не подключён', 'AE disconnected'); status('Для работы установите панель в AE. Просмотр интерфейса: index.html?demo=1', false, 'Install the panel in AE to use it. Interface preview: index.html?demo=1'); }
}());




