$ErrorActionPreference = 'Stop'
if (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) { throw 'Close After Effects before removing T-RUSH.' }
$taskTarget = Join-Path $env:APPDATA 'Adobe\CEP\extensions\local.titleflow'
if (Test-Path -LiteralPath $taskTarget) { Remove-Item -LiteralPath $taskTarget -Recurse -Force }
Write-Host 'T-RUSH removed. Your AE projects, renders and backups were kept.'
Read-Host 'Press Enter to close'
