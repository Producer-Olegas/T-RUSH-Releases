$ErrorActionPreference = 'Stop'
$taskSource = Split-Path -Parent $PSScriptRoot
$taskTarget = Join-Path $env:APPDATA 'Adobe\CEP\extensions\local.titleflow'
if (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) { throw 'Close After Effects before installing or updating T-RUSH.' }
foreach ($taskRequired in @('CSXS', 'host', 'js', 'assets', 'updater', 'index.html', 'style.css', 'package.json')) {
    if (!(Test-Path -LiteralPath (Join-Path $taskSource $taskRequired))) { throw "Incomplete package: $taskRequired. Extract the ZIP first." }
}
$taskBackups = Join-Path $env:APPDATA 'TitleFlow\backups'
if (Test-Path $taskTarget) {
    New-Item -ItemType Directory -Force -Path $taskBackups | Out-Null
    Copy-Item -LiteralPath $taskTarget -Destination (Join-Path $taskBackups ('titleflow-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))) -Recurse
    Remove-Item -LiteralPath $taskTarget -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $taskTarget | Out-Null
foreach ($taskItem in @('CSXS', 'host', 'js', 'assets', 'updater', 'index.html', 'style.css', 'package.json')) {
    Copy-Item -LiteralPath (Join-Path $taskSource $taskItem) -Destination $taskTarget -Recurse -Force
}
foreach ($taskRuntime in @('11', '12', '13')) {
    $taskRegistry = "HKCU:\Software\Adobe\CSXS.$taskRuntime"
    New-Item -Path $taskRegistry -Force | Out-Null
    New-ItemProperty -Path $taskRegistry -Name 'PlayerDebugMode' -PropertyType String -Value '1' -Force | Out-Null
}
Write-Host "T-RUSH installed to: $taskTarget"
Write-Host 'CEP developer mode was enabled for the current Windows user.'
Write-Host 'Restart After Effects, then open Window > Extensions > T-RUSH.'
Read-Host 'Press Enter to close'
