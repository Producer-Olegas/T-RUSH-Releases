@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installers\install-windows.ps1"
if errorlevel 1 (
  echo.
  echo Installation failed. Send a screenshot of this window to the developer.
  pause
)
