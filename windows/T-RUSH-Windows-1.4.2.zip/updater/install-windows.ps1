param([Parameter(Mandatory=$true)][string]$Work, [Parameter(Mandatory=$true)][string]$Target)
$ErrorActionPreference = 'Stop'
$taskMoved = $false
$taskBackup = $null
$taskLock = $null
function Get-PayloadHash([string]$taskPath) {
    $taskAlgorithm = [Security.Cryptography.SHA256]::Create()
    $taskStream = [IO.File]::OpenRead($taskPath)
    try { return [BitConverter]::ToString($taskAlgorithm.ComputeHash($taskStream)).Replace('-','').ToLowerInvariant() }
    finally { $taskStream.Dispose(); $taskAlgorithm.Dispose() }
}
try {
    $taskExpected = [IO.Path]::GetFullPath((Join-Path $env:APPDATA 'Adobe\CEP\extensions\local.titleflow'))
    if ([IO.Path]::GetFullPath($Target) -ne $taskExpected) { throw 'Unsupported installation path' }
    function Assert-PlainPath([string]$taskPath) {
        $taskItem = Get-Item -LiteralPath $taskPath -Force
        while ($null -ne $taskItem) {
            if ($taskItem.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked path is unsupported' }
            if ($taskItem -is [IO.FileInfo]) { $taskItem = $taskItem.Directory } else { $taskItem = $taskItem.Parent }
        }
    }
    Assert-PlainPath $Target
    Assert-PlainPath $Work
    $taskState = Join-Path $env:APPDATA 'TitleFlow'
    New-Item -ItemType Directory -Force -Path $taskState | Out-Null
    Assert-PlainPath $taskState
    $taskLock = [IO.File]::Open((Join-Path $taskState 'windows-update.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $taskPanel = Join-Path $Work 'panel'
    # Windows PowerShell 5.1 can wrap a JSON array as one pipeline object.
    # Assign it directly so foreach sees individual file records, not an array record.
    $taskHashes = Get-Content -LiteralPath (Join-Path $Work 'hashes.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    function Assert-Payload {
        foreach ($taskFile in $taskHashes) {
            if ($taskFile.path -notmatch '^(index\.html|style\.css|package\.json|CSXS/manifest\.xml|host/main\.jsx|js/[a-z0-9-]+\.js|updater/[a-z0-9-]+\.(js|ps1)|assets/[a-z0-9-]+\.png)$') { throw 'Invalid payload path' }
            $taskPath = Join-Path $taskPanel $taskFile.path
            Assert-PlainPath $taskPath
            if ((Get-PayloadHash $taskPath) -ne $taskFile.sha256) { throw 'Payload checksum mismatch' }
        }
        if (@(Get-ChildItem -LiteralPath $taskPanel -File -Recurse).Count -ne $taskHashes.Count) { throw 'Unexpected payload files' }
    }
    Assert-Payload
    Set-Content -LiteralPath (Join-Path $Work 'ready') -Value 'waiting-for-AE-exit'
    $taskDeadline = (Get-Date).AddHours(2)
    while (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) {
        if ((Get-Date) -gt $taskDeadline) { throw 'Timed out waiting for After Effects to exit' }
        Start-Sleep -Seconds 2
    }
    Assert-PlainPath $Target
    Assert-Payload
    if (@(Get-ChildItem -LiteralPath $Target -Recurse -Force | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Linked installation content is unsupported' }
    $taskBackups = Join-Path $env:APPDATA 'TitleFlow\backups'
    New-Item -ItemType Directory -Force -Path $taskBackups | Out-Null
    Assert-PlainPath $taskBackups
    $taskBackup = Join-Path $taskBackups ('titleflow-update-' + [guid]::NewGuid().ToString('N'))
    # Copy before changing the installed directory. Preserve the backup after success.
    Copy-Item -LiteralPath $Target -Destination $taskBackup -Recurse
    if (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) { throw 'After Effects restarted; update cancelled' }
    # Only this verified, fixed extension directory can be replaced.
    if ([IO.Path]::GetFullPath($Target) -ne $taskExpected) { throw 'Invalid target' }
    Assert-PlainPath $Target
    $taskOld = Join-Path $taskBackups ('titleflow-previous-' + [guid]::NewGuid().ToString('N'))
    Move-Item -LiteralPath $Target -Destination $taskOld
    $taskMoved = $true
    New-Item -ItemType Directory -Path $Target | Out-Null
    Copy-Item -Path (Join-Path $taskPanel '*') -Destination $Target -Recurse
    foreach ($taskFile in $taskHashes) {
        if ((Get-PayloadHash (Join-Path $Target $taskFile.path)) -ne $taskFile.sha256) { throw 'Installed checksum mismatch' }
    }
    Set-Content -LiteralPath (Join-Path $Work 'installed') -Value $Target
    # Keep the previous directory too; no recursive deletion is needed for installation.
    $taskMoved = $false
} catch {
    $taskError = $_.Exception.Message
    if ($taskMoved) {
        try {
            if (Test-Path -LiteralPath $Target) { Move-Item -LiteralPath $Target -Destination (Join-Path $taskBackups ('titleflow-failed-' + [guid]::NewGuid().ToString('N'))) }
            Move-Item -LiteralPath $taskOld -Destination $Target
        } catch { $taskError += '; rollback: ' + $_.Exception.Message }
    }
    Add-Content -LiteralPath (Join-Path $Work 'install.log') -Value ($taskError + ' | ' + $_.ScriptStackTrace) -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $Work 'failed') -Value $taskError -Encoding UTF8
    exit 1
} finally {
    if ($null -ne $taskLock) { $taskLock.Dispose() }
}
