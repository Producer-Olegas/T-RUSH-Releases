param([switch]$Probe)
# Kept under updater/ for compatibility with already-installed Windows update allowlists.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::InputEncoding = New-Object Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
try {
    Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Runtime.InteropServices;
public static class TrushFolderPicker {
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("shell32.dll", CharSet=CharSet.Unicode, PreserveSig=true)]
    static extern int SHCreateItemFromParsingName(string name, IntPtr bind, ref Guid iid, out IShellItem item);
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    public struct Filter { [MarshalAs(UnmanagedType.LPWStr)] public string name; [MarshalAs(UnmanagedType.LPWStr)] public string spec; }
    [ComImport, Guid("42f85136-db7e-439c-85f1-e4075d135fc8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IFileDialog {
        [PreserveSig] int Show(IntPtr owner);
        void SetFileTypes(uint count, [MarshalAs(UnmanagedType.LPArray)] Filter[] filters);
        void SetFileTypeIndex(uint index); void GetFileTypeIndex(out uint index);
        void Advise(IntPtr events, out uint cookie); void Unadvise(uint cookie);
        void SetOptions(uint options); void GetOptions(out uint options);
        void SetDefaultFolder(IShellItem item); void SetFolder(IShellItem item);
        void GetFolder(out IShellItem item); void GetCurrentSelection(out IShellItem item);
        void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string name);
        void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string title);
        void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string text);
        void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string text);
        void GetResult(out IShellItem item);
    }
    [ComImport, Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IShellItem {
        void BindToHandler(IntPtr bind, ref Guid handler, ref Guid iid, out IntPtr result);
        void GetParent(out IShellItem parent);
        void GetDisplayName(uint type, out IntPtr name);
    }
    static IFileDialog Create() {
        // CLSID_FileOpenDialog: the Windows Common Item Dialog, not the legacy tree picker.
        return (IFileDialog)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("dc1c5a9c-e88a-4dde-a5a1-60f82a20aef7")));
    }
    public static void Probe() { var dialog = Create(); try { uint options; dialog.GetOptions(out options); } finally { Marshal.FinalReleaseComObject(dialog); } }
    public static string Pick(string initial, string title) {
        IntPtr owner = GetForegroundWindow();
        var dialog = Create(); IShellItem start = null, selected = null;
        try {
            uint options; dialog.GetOptions(out options);
            dialog.SetOptions(options | 0x20u | 0x40u | 0x800u | 0x8u); // PICKFOLDERS, FORCEFILESYSTEM, PATHMUSTEXIST, NOCHANGEDIR
            dialog.SetTitle(title);
            if (!String.IsNullOrEmpty(initial) && Directory.Exists(initial)) {
                Guid iid = new Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe");
                if (SHCreateItemFromParsingName(initial, IntPtr.Zero, ref iid, out start) >= 0) dialog.SetFolder(start);
            }
            int hr = dialog.Show(owner);
            if (hr == unchecked((int)0x800704C7)) return null;
            if (hr < 0) Marshal.ThrowExceptionForHR(hr);
            dialog.GetResult(out selected); IntPtr value;
            selected.GetDisplayName(0x80058000u, out value); // SIGDN_FILESYSPATH
            try { return Marshal.PtrToStringUni(value); } finally { Marshal.FreeCoTaskMem(value); }
        } finally {
            if (selected != null) Marshal.FinalReleaseComObject(selected);
            if (start != null) Marshal.FinalReleaseComObject(start);
            Marshal.FinalReleaseComObject(dialog);
        }
    }
}
'@
    if ($Probe) { [TrushFolderPicker]::Probe(); $result = @{ok=$true; probe=$true} }
    else {
        $request = [Console]::In.ReadToEnd() | ConvertFrom-Json
        $selected = [TrushFolderPicker]::Pick([string]$request.initialFolder, [string]$request.title)
        $result = @{ok=$true; cancelled=($null -eq $selected); path=$selected}
    }
} catch { $result = @{ok=$false; error=$_.Exception.Message} }
[Console]::WriteLine(($result | ConvertTo-Json -Compress))
