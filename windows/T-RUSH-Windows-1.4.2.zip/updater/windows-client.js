'use strict';
const fs = require('fs'), path = require('path'), https = require('https'), crypto = require('crypto'), cp = require('child_process'), os = require('os');
const channel = 'https://raw.githubusercontent.com/Producer-Olegas/T-RUSH-Releases/main/windows/';
const allowed = /^(index\.html|style\.css|package\.json|CSXS\/manifest\.xml|host\/main\.jsx|js\/[a-z0-9-]+\.js|updater\/[a-z0-9-]+\.(js|ps1)|assets\/[a-z0-9-]+\.png)$/i;
const newer = require('./client').newer;
function validateInfo(info) {
  if (!info || !/^\d+\.\d+\.\d+$/.test(info.version) || info.url !== channel + info.version + '.json' || !/^[a-f0-9]{64}$/.test(info.sha256)) throw new Error('Invalid Windows update manifest');
  return info;
}
function get(url, limit) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'T-RUSH-Windows-updater', 'Cache-Control': 'no-cache' } }, res => {
      if (res.statusCode !== 200) { res.resume(); reject(new Error('HTTP ' + res.statusCode)); return; }
      let size = 0; const chunks = [];
      res.on('data', chunk => { size += chunk.length; if (size > limit) req.destroy(new Error('Update too large')); else chunks.push(chunk); });
      res.on('end', () => resolve(Buffer.concat(chunks))); res.on('error', reject);
    });
    req.setTimeout(15000, () => req.destroy(new Error('Timeout'))); req.on('error', reject);
  });
}
async function check(current) {
  const info = validateInfo(JSON.parse((await get(channel + 'latest.json?t=' + Date.now(), 65536)).toString('utf8')));
  return newer(info.version, current) ? info : null;
}
function validateBundle(bundle, version) {
  if (!bundle || bundle.version !== version || !Array.isArray(bundle.files) || bundle.files.length > 100) throw new Error('Invalid Windows update package');
  const seen = new Set();
  for (const file of bundle.files) {
    const key = String(file.path).toLowerCase();
    if (!allowed.test(file.path) || seen.has(key) || /^(js\/demo\.js)$/i.test(file.path)) throw new Error('Invalid update file: ' + file.path);
    seen.add(key);
    if (typeof file.data !== 'string' || crypto.createHash('sha256').update(Buffer.from(file.data, 'base64')).digest('hex') !== file.sha256) throw new Error('Damaged update file: ' + file.path);
  }
  for (const name of ['index.html', 'style.css', 'package.json', 'csxs/manifest.xml', 'host/main.jsx', 'js/app.js', 'js/core.js', 'js/google.js', 'js/updates.js', 'updater/client.js', 'updater/windows-client.js', 'updater/install-windows.ps1']) {
    if (!seen.has(name)) throw new Error('Incomplete Windows update: ' + name);
  }
  const pkg = JSON.parse(Buffer.from(bundle.files.find(f => f.path.toLowerCase() === 'package.json').data, 'base64').toString('utf8'));
  if (pkg.version !== version) throw new Error('Package version mismatch');
  return bundle;
}
function validateTarget(target) {
  if (process.platform !== 'win32') throw new Error('Windows updates only');
  const expected = path.join(process.env.APPDATA || '', 'Adobe/CEP/extensions/local.titleflow');
  if (!process.env.APPDATA || path.resolve(target).toLowerCase() !== path.resolve(expected).toLowerCase()) throw new Error('Unsupported installation path');
  for (let p = expected; ; p = path.dirname(p)) {
    if (fs.lstatSync(p).isSymbolicLink()) throw new Error('Linked installation path is unsupported');
    if (path.dirname(p) === p) break;
  }
  return expected;
}
async function launchHelper(work, target) {
  const helper = path.join(work, 'install-windows.ps1');
  const logPath = path.join(work, 'launch.log');
  const shell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32/WindowsPowerShell/v1.0/powershell.exe');
  const quote = value => "'" + value.replace(/'/g, "''") + "'";
  const command = '& ' + quote(helper) + ' -Work ' + quote(work) + ' -Target ' + quote(target);
  const payload = Buffer.from(command, 'utf16le').toString('base64');
  const stderr = path.join(work, 'helper-stderr.log');
  // DETACHED_PROCESS makes Windows PowerShell silently exit before running scripts.
  // A normal short-lived PowerShell starts an independent hidden helper instead.
  const launcher = '$taskChild = Start-Process -FilePath ' + quote(shell) +
    " -WindowStyle Hidden -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand'," + quote(payload) +
    ') -RedirectStandardOutput ' + quote(path.join(work, 'helper-stdout.log')) + ' -RedirectStandardError ' + quote(stderr) + ' -PassThru; $taskHandle = $taskChild.Handle; ' +
    'while (!(Test-Path -LiteralPath ' + quote(path.join(work, 'ready')) + ') -and !(Test-Path -LiteralPath ' + quote(path.join(work, 'failed')) + ')) { ' +
    '$taskChild.Refresh(); if ($taskChild.HasExited) { [IO.File]::WriteAllText(' + quote(path.join(work, 'failed')) + ", 'Windows helper exited (' + $taskChild.ExitCode + '): ' + [IO.File]::ReadAllText(" + quote(stderr) + ')); break }; Start-Sleep -Milliseconds 100 }';
  const encoded = Buffer.from(launcher, 'utf16le').toString('base64');
  const output = fs.openSync(logPath, 'a');
  let child, launchError = null, exited = false, exitCode;
  try {
    child = cp.spawn(shell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { cwd: work, detached: false, windowsHide: true, stdio: ['ignore', output, output] });
    child.once('error', error => { launchError = error; });
    child.once('exit', code => { exited = true; exitCode = code; });
    child.unref();
  } finally { fs.closeSync(output); }
  // Poll the actual acknowledgement, without relying on Node's newer spawn event.
  for (let i = 0; i < 150; i++) {
    if (fs.existsSync(path.join(work, 'ready'))) return work;
    const failed = path.join(work, 'failed');
    if (fs.existsSync(failed)) throw new Error('Windows update helper: ' + fs.readFileSync(failed, 'utf8').trim());
    if (launchError) { fs.appendFileSync(logPath, launchError.message); throw new Error('Cannot launch Windows updater: ' + launchError.message); }
    if (exited) throw new Error('Windows updater launcher exited (' + exitCode + '): ' + fs.readFileSync(logPath, 'utf8').slice(-1500));
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error('Windows updater did not acknowledge startup; see ' + logPath);
}
async function prepare(info, target) {
  validateInfo(info); target = validateTarget(target);
  const body = await get(info.url, 16 * 1024 * 1024);
  if (crypto.createHash('sha256').update(body).digest('hex') !== info.sha256) throw new Error('Update checksum mismatch');
  const bundle = validateBundle(JSON.parse(body.toString('utf8')), info.version);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'trush-win-update-'));
  const staged = path.join(work, 'panel'); fs.mkdirSync(staged);
  for (const file of bundle.files) {
    const dest = path.join(staged, file.path); fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, Buffer.from(file.data, 'base64'));
  }
  fs.writeFileSync(path.join(work, 'hashes.json'), JSON.stringify(bundle.files.map(file => ({ path: file.path, sha256: file.sha256 }))));
  // Execute the currently installed helper, not code downloaded in the update.
  const helper = path.join(work, 'install-windows.ps1'); fs.copyFileSync(path.join(__dirname, 'install-windows.ps1'), helper);
  return launchHelper(work, target);
}
module.exports = { newer, check, validateInfo, validateBundle, validateTarget, launchHelper, prepare };
