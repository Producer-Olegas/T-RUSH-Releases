'use strict';
const fs = require('fs'), path = require('path'), https = require('https'), crypto = require('crypto'), cp = require('child_process'), os = require('os');
const URL = require('url').URL;
const endpoint = 'https://raw.githubusercontent.com/Producer-Olegas/T-RUSH-Releases/main/mac/latest.json';
const allowed = /^(index\.html|style\.css|package\.json|CSXS\/manifest\.xml|host\/main\.jsx|js\/[a-z0-9-]+\.js|updater\/[a-z0-9-]+\.(js|sh)|assets\/[a-z0-9-]+\.png)$/i;
function newer(a,b) { if(!/^\d+\.\d+\.\d+$/.test(a)) return false; const x=a.split('.').map(Number),y=b.split('.').map(Number); for(let i=0;i<3;i++) if(x[i]!==y[i]) return x[i]>y[i]; return false; }
function get(url, limit) { return new Promise((resolve,reject)=>{const req=https.get(url,{headers:{'User-Agent':'T-RUSH-updater','Cache-Control':'no-cache'}},res=>{if(res.statusCode!==200){res.resume();return reject(new Error('HTTP '+res.statusCode));}let size=0,chunks=[];res.on('data',chunk=>{size+=chunk.length;if(size>limit)req.destroy(new Error('Update too large'));else chunks.push(chunk);});res.on('end',()=>resolve(Buffer.concat(chunks)));res.on('error',reject);});req.setTimeout(15000,()=>req.destroy(new Error('Timeout')));req.on('error',reject);}); }
async function check(current) { const info=JSON.parse((await get(endpoint+'?t='+Date.now(),65536)).toString('utf8')); if(!/^\d+\.\d+\.\d+$/.test(info.version))throw new Error('Invalid version');if(!newer(info.version,current))return null;const url=new URL(info.url);if(url.origin!=='https://raw.githubusercontent.com'||!url.pathname.startsWith('/Producer-Olegas/T-RUSH-Releases/main/mac/'))throw new Error('Invalid update address');if(!/^[a-f0-9]{64}$/.test(info.sha256))throw new Error('Invalid checksum');return info; }
function validateBundle(bundle, version) { if(bundle.version!==version||!Array.isArray(bundle.files)||bundle.files.length>100)throw new Error('Invalid update package');const seen=new Set();for(const file of bundle.files){if(!allowed.test(file.path)||seen.has(file.path))throw new Error('Invalid file: '+file.path);seen.add(file.path);const data=Buffer.from(file.data,'base64');if(crypto.createHash('sha256').update(data).digest('hex')!==file.sha256)throw new Error('Damaged file: '+file.path);}for(const required of ['index.html','CSXS/manifest.xml','js/app.js','updater/client.js'])if(!seen.has(required))throw new Error('Incomplete update');return bundle; }
async function prepare(info, target) {
 if(process.platform!=='darwin')throw new Error('Mac updates only');
 const expected=path.join(os.homedir(),'Library/Application Support/Adobe/CEP/extensions/local.titleflow');
 if(path.resolve(target)!==expected||fs.lstatSync(target).isSymbolicLink())throw new Error('Unsupported installation path');
 const body=await get(info.url,16*1024*1024);if(crypto.createHash('sha256').update(body).digest('hex')!==info.sha256)throw new Error('Update checksum mismatch');
 const bundle=validateBundle(JSON.parse(body.toString('utf8')),info.version);
 const work=fs.mkdtempSync(path.join(os.tmpdir(),'trush-update-'));fs.chmodSync(work,0o700);const staged=path.join(work,'panel');fs.mkdirSync(staged);
 for(const file of bundle.files){const dest=path.join(staged,file.path);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,Buffer.from(file.data,'base64'));}
 const helper=path.join(work,'install.sh');fs.copyFileSync(path.join(__dirname,'install.sh'),helper);
 const label='local.trush.update.'+Date.now();
 cp.execFileSync('/bin/launchctl',['submit','-l',label,'-o',path.join(work,'install.log'),'-e',path.join(work,'install.log'),'--','/bin/bash',helper,staged,target,work],{timeout:10000});
 return work;
}
module.exports={newer,check,validateBundle,prepare};
